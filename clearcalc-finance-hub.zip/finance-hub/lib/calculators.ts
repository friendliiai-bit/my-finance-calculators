export type CalcKey = "fire" | "debt" | "mortgage" | "tax" | "auto";

export interface CalcMeta {
  key: CalcKey;
  href: string;
  navLabel: string;
  title: string;
  tagline: string;
  /** The plain question a visitor arrives with */
  question: string;
  metaTitle: string;
  metaDescription: string;
}

export const CALCULATORS: Record<CalcKey, CalcMeta> = {
  fire: {
    key: "fire",
    href: "/fire-calc",
    navLabel: "FIRE & growth",
    title: "FIRE & Compound Growth Calculator",
    tagline:
      "Find the portfolio that covers your spending and the age you reach it, in today's dollars.",
    question: "When can I stop working?",
    metaTitle: "FIRE & Compound Growth Calculator",
    metaDescription:
      "Calculate your FI number, years to financial independence and retirement age with a live compound growth chart. Adjust savings, returns, inflation and withdrawal rate.",
  },
  debt: {
    key: "debt",
    href: "/debt-payoff",
    navLabel: "0% APR payoff",
    title: "0% APR Debt Payoff Simulator",
    tagline:
      "See whether a balance transfer beats your current card, fee included, and what you must pay to finish in time.",
    question: "Will a 0% transfer beat my current card?",
    metaTitle: "0% APR Balance Transfer Payoff Simulator",
    metaDescription:
      "Simulate a 0% APR balance transfer. Compare payoff time, transfer fee and interest saved against staying on your current card, with a month-by-month chart.",
  },
  mortgage: {
    key: "mortgage",
    href: "/mortgage-payoff",
    navLabel: "Mortgage payoff",
    title: "Mortgage Extra Payment Calculator",
    tagline:
      "Add a monthly or yearly extra payment and see the years and interest you remove from your loan.",
    question: "How much sooner can I own my home?",
    metaTitle: "Mortgage Extra Payment Calculator",
    metaDescription:
      "See how extra mortgage payments shorten your loan and cut interest. Compare your current schedule with monthly or annual extra principal payments on a live chart.",
  },
  tax: {
    key: "tax",
    href: "/paycheck-tax",
    navLabel: "Side-hustle tax",
    title: "Side-Hustle Net Tax Estimator",
    tagline:
      "Estimate federal, self-employment and state tax on freelance income, and what to set aside each quarter.",
    question: "What do I keep from my side income?",
    metaTitle: "Side-Hustle Tax Estimator (2026)",
    metaDescription:
      "Estimate tax on side-hustle income for 2026: self-employment tax, federal and state income tax, the QBI deduction and quarterly estimated payments.",
  },
  auto: {
    key: "auto",
    href: "/auto-loan",
    navLabel: "Auto loan vs cash",
    title: "Auto Loan vs Cash Calculator",
    tagline:
      "Compare the interest a car loan costs with what your cash could earn if you kept it invested.",
    question: "Should I finance the car or pay cash?",
    metaTitle: "Auto Loan vs Cash Calculator",
    metaDescription:
      "Should you finance a car or pay cash? Compare loan interest with investment growth, see your monthly payment and find the break-even return.",
  },
};

export const CALCULATOR_LIST: CalcMeta[] = [
  CALCULATORS.fire,
  CALCULATORS.debt,
  CALCULATORS.mortgage,
  CALCULATORS.tax,
  CALCULATORS.auto,
];
