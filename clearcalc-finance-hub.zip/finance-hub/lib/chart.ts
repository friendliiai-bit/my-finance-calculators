/**
 * Chart tokens. Series colors follow a fixed order (never cycled) and were checked for
 * adjacent-pair separation, including for color-vision deficiency, with the dataviz validator.
 * Marks carry the color; text always uses ink tokens.
 */
export const C = {
  blue: "#2a78d6",
  orange: "#eb6834",
  aqua: "#1baf7a",
  yellow: "#eda100",
  magenta: "#e87ba4",
  ink: "#14233b",
  inkSoft: "#4b5a73",
  muted: "#66728a",
  grid: "#e6e9ee",
  axis: "#c5ccd6",
  surface: "#ffffff",
} as const;

export const axisTick = { fill: C.muted, fontSize: 12 } as const;
