export const SITE = {
  name: "ClearCalc",
  /** Set NEXT_PUBLIC_SITE_URL in production so canonical URLs and the sitemap are correct. */
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://clearcalc.example",
  tagline: "Financial calculators for decisions that are hard to undo",
  description:
    "Five free financial calculators with live charts: FIRE and compound growth, 0% APR debt payoff, mortgage extra payments, side-hustle taxes and auto loan versus cash.",
};
