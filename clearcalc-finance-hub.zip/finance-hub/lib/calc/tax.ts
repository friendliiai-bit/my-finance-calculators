/**
 * Simplified US federal estimate for a W-2 earner with side-hustle income.
 * Tax year 2026 figures: IRS Rev. Proc. 2025-32 (brackets, standard deduction)
 * and the SSA announcement of the $184,500 Social Security wage base.
 */

export type FilingStatus = "single" | "mfj" | "hoh";

interface Bracket {
  upTo: number;
  rate: number;
}

export const BRACKETS_2026: Record<FilingStatus, Bracket[]> = {
  single: [
    { upTo: 12400, rate: 0.1 },
    { upTo: 50400, rate: 0.12 },
    { upTo: 105700, rate: 0.22 },
    { upTo: 201775, rate: 0.24 },
    { upTo: 256225, rate: 0.32 },
    { upTo: 640600, rate: 0.35 },
    { upTo: Infinity, rate: 0.37 },
  ],
  mfj: [
    { upTo: 24800, rate: 0.1 },
    { upTo: 100800, rate: 0.12 },
    { upTo: 211400, rate: 0.22 },
    { upTo: 403550, rate: 0.24 },
    { upTo: 512450, rate: 0.32 },
    { upTo: 768700, rate: 0.35 },
    { upTo: Infinity, rate: 0.37 },
  ],
  hoh: [
    { upTo: 17700, rate: 0.1 },
    { upTo: 67450, rate: 0.12 },
    { upTo: 105700, rate: 0.22 },
    { upTo: 201750, rate: 0.24 },
    { upTo: 256200, rate: 0.32 },
    { upTo: 640600, rate: 0.35 },
    { upTo: Infinity, rate: 0.37 },
  ],
};

export const STANDARD_DEDUCTION_2026: Record<FilingStatus, number> = {
  single: 16100,
  mfj: 32200,
  hoh: 24150,
};

export const SS_WAGE_BASE_2026 = 184500;

const ADDL_MEDICARE_THRESHOLD: Record<FilingStatus, number> = {
  single: 200000,
  mfj: 250000,
  hoh: 200000,
};

/**
 * Round taxable-income levels above which the QBI deduction's income limits can start to
 * apply. The exact threshold is indexed every year, so this is a deliberately round
 * heuristic used only to show a warning, never to change the math.
 */
const QBI_CAUTION: Record<FilingStatus, number> = {
  single: 200000,
  mfj: 400000,
  hoh: 200000,
};

export const FILING_LABELS: Record<FilingStatus, string> = {
  single: "Single",
  mfj: "Married filing jointly",
  hoh: "Head of household",
};

export function federalIncomeTax(taxable: number, status: FilingStatus): number {
  let tax = 0;
  let lower = 0;
  for (const b of BRACKETS_2026[status]) {
    if (taxable <= lower) break;
    tax += (Math.min(taxable, b.upTo) - lower) * b.rate;
    lower = b.upTo;
  }
  return tax;
}

export interface TaxInputs {
  status: FilingStatus;
  /** Day-job wages, dollars per year */
  w2Income: number;
  sideRevenue: number;
  sideExpenses: number;
  /** Flat state income tax estimate, percent */
  stateRate: number;
  /** Retirement contribution as a percent of net self-employment earnings (max 20) */
  retirementPct: number;
}

interface Totals {
  netProfit: number;
  seTax: number;
  addlMedicare: number;
  halfSe: number;
  retirement: number;
  agi: number;
  qbi: number;
  qbiMayBeLimited: boolean;
  taxableIncome: number;
  fedTax: number;
  stateTax: number;
}

function totals(i: TaxInputs, includeSide: boolean): Totals {
  const netProfit = includeSide
    ? Math.max(0, i.sideRevenue - i.sideExpenses)
    : 0;

  const seEarnings = netProfit >= 400 ? netProfit * 0.9235 : 0;
  const ssRoom = Math.max(0, SS_WAGE_BASE_2026 - i.w2Income);
  const seTax =
    0.124 * Math.min(seEarnings, ssRoom) + 0.029 * seEarnings;

  const addlMedicare =
    0.009 *
    Math.max(0, i.w2Income + seEarnings - ADDL_MEDICARE_THRESHOLD[i.status]);

  const halfSe = seTax / 2;
  const retirement =
    Math.max(0, netProfit - halfSe) *
    (Math.min(Math.max(i.retirementPct, 0), 20) / 100);

  const agi = i.w2Income + netProfit - halfSe - retirement;
  const std = STANDARD_DEDUCTION_2026[i.status];
  const beforeQbi = Math.max(0, agi - std);
  const qbiBase = Math.max(0, netProfit - halfSe - retirement);
  const qbi = Math.min(0.2 * qbiBase, 0.2 * beforeQbi);
  const qbiMayBeLimited = beforeQbi > QBI_CAUTION[i.status];
  const taxableIncome = Math.max(0, beforeQbi - qbi);

  const fedTax = federalIncomeTax(taxableIncome, i.status);
  const stateTax = (i.stateRate / 100) * Math.max(0, agi - std);

  return {
    netProfit,
    seTax,
    addlMedicare,
    halfSe,
    retirement,
    agi,
    qbi,
    qbiMayBeLimited,
    taxableIncome,
    fedTax,
    stateTax,
  };
}

export interface TaxSegment {
  key: "keep" | "federal" | "se" | "state" | "expenses";
  label: string;
  value: number;
}

export interface TaxCurvePoint {
  revenue: number;
  keep: number;
  tax: number;
}

export interface TaxResult {
  netProfit: number;
  /** Self-employment tax (plus any added Medicare tax) caused by the side income */
  seTax: number;
  fedTax: number;
  stateTax: number;
  totalTax: number;
  keep: number;
  effectiveRate: number;
  quarterly: number;
  qbiDeduction: number;
  /** True when income is high enough that the QBI deduction may be reduced or lost */
  qbiMayBeLimited: boolean;
  halfSeDeduction: number;
  retirement: number;
  marginalRate: number;
  segments: TaxSegment[];
  curve: TaxCurvePoint[];
}

function incremental(i: TaxInputs) {
  const withSide = totals(i, true);
  const without = totals(i, false);
  const seTax =
    withSide.seTax + withSide.addlMedicare - (without.seTax + without.addlMedicare);
  const fedTax = withSide.fedTax - without.fedTax;
  const stateTax = withSide.stateTax - without.stateTax;
  return { withSide, seTax, fedTax, stateTax, total: seTax + fedTax + stateTax };
}

export function estimateTax(i: TaxInputs): TaxResult {
  const { withSide, seTax, fedTax, stateTax, total } = incremental(i);
  const netProfit = withSide.netProfit;
  const keep = netProfit - total;

  // Marginal rate on the next $1,000 of side revenue (no extra expenses)
  const bump = incremental({ ...i, sideRevenue: i.sideRevenue + 1000 });
  const marginalRate = (bump.total - total) / 1000; // tax per extra dollar of revenue

  const spentOnExpenses = Math.min(i.sideExpenses, i.sideRevenue);

  const segments: TaxSegment[] = [
    { key: "keep", label: "You keep", value: Math.max(0, keep) },
    { key: "federal", label: "Federal income tax", value: fedTax },
    { key: "se", label: "Self-employment tax", value: seTax },
    { key: "state", label: "State income tax", value: stateTax },
    { key: "expenses", label: "Business expenses", value: spentOnExpenses },
  ];

  // How take-home scales with revenue, holding the expense ratio steady.
  const ratio = i.sideRevenue > 0 ? Math.min(1, i.sideExpenses / i.sideRevenue) : 0;
  const maxRevenue = Math.min(
    300000,
    Math.max(20000, Math.ceil((i.sideRevenue * 2) / 5000) * 5000),
  );
  const steps = 24;
  const curve: TaxCurvePoint[] = [];
  for (let s = 0; s <= steps; s++) {
    const revenue = (maxRevenue / steps) * s;
    const r = incremental({
      ...i,
      sideRevenue: revenue,
      sideExpenses: revenue * ratio,
    });
    curve.push({
      revenue,
      keep: Math.max(0, r.withSide.netProfit - r.total),
      tax: r.total,
    });
  }

  return {
    netProfit,
    seTax,
    fedTax,
    stateTax,
    totalTax: total,
    keep,
    effectiveRate: netProfit > 0 ? total / netProfit : 0,
    quarterly: total / 4,
    qbiDeduction: withSide.qbi,
    qbiMayBeLimited: withSide.qbiMayBeLimited && netProfit > 0,
    halfSeDeduction: withSide.halfSe,
    retirement: withSide.retirement,
    marginalRate,
    segments,
    curve,
  };
}
