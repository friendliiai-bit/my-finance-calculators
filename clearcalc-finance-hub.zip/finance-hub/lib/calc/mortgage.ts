export interface MortgageInputs {
  /** Current loan balance, dollars */
  balance: number;
  /** Annual interest rate, percent */
  rate: number;
  /** Years left on the loan */
  remainingYears: number;
  /** Extra principal paid every month */
  extraMonthly: number;
  /** Lump sum added once a year (month 12, 24, ...) */
  annualLump: number;
}

export interface Amortization {
  payment: number;
  months: number;
  interest: number;
  balances: number[];
}

export interface MortgagePoint {
  year: number;
  standard: number;
  accelerated: number;
}

export interface MortgageResult {
  payment: number;
  standard: Amortization;
  accelerated: Amortization;
  interestSaved: number;
  monthsSaved: number;
  points: MortgagePoint[];
}

export function monthlyPayment(
  principal: number,
  annualRatePct: number,
  months: number,
): number {
  const r = annualRatePct / 1200;
  if (months <= 0) return principal;
  if (r === 0) return principal / months;
  return (principal * r) / (1 - Math.pow(1 + r, -months));
}

export function amortize(
  principal: number,
  annualRatePct: number,
  termMonths: number,
  extraMonthly: number,
  annualLump: number,
): Amortization {
  const payment = monthlyPayment(principal, annualRatePct, termMonths);
  const r = annualRatePct / 1200;
  let balance = principal;
  let interest = 0;
  let month = 0;
  const balances = [balance];

  while (balance > 0.005 && month < termMonths + 12) {
    month++;
    const monthlyInterest = balance * r;
    interest += monthlyInterest;
    balance += monthlyInterest;
    const lump = month % 12 === 0 ? annualLump : 0;
    balance -= Math.min(payment + extraMonthly + lump, balance);
    balances.push(Math.max(0, balance));
  }

  return { payment, months: month, interest, balances };
}

export function simulateMortgage(i: MortgageInputs): MortgageResult {
  const termMonths = Math.round(i.remainingYears * 12);
  const standard = amortize(i.balance, i.rate, termMonths, 0, 0);
  const accelerated = amortize(
    i.balance,
    i.rate,
    termMonths,
    i.extraMonthly,
    i.annualLump,
  );

  const years = Math.ceil(standard.months / 12);
  const points: MortgagePoint[] = [];
  for (let y = 0; y <= years; y++) {
    points.push({
      year: y,
      standard: standard.balances[y * 12] ?? 0,
      accelerated: accelerated.balances[y * 12] ?? 0,
    });
  }

  return {
    payment: standard.payment,
    standard,
    accelerated,
    interestSaved: standard.interest - accelerated.interest,
    monthsSaved: standard.months - accelerated.months,
    points,
  };
}
