export interface FireInputs {
  currentAge: number;
  currentSavings: number;
  monthlyContribution: number;
  /** Nominal annual return, percent */
  annualReturn: number;
  /** Annual inflation, percent */
  inflation: number;
  annualExpenses: number;
  /** Safe withdrawal rate, percent */
  withdrawalRate: number;
}

export interface FirePoint {
  year: number;
  age: number;
  /** Portfolio value in today's dollars */
  balance: number;
  /** Savings plus contributions made so far, in today's dollars */
  contributed: number;
}

export interface FireResult {
  fiNumber: number;
  monthsToFi: number | null;
  yearsToFi: number | null;
  fiAge: number | null;
  /** Share of the FI number already saved (0 to 1+) */
  progress: number;
  realReturn: number;
  points: FirePoint[];
}

const MAX_YEARS = 60;

export function simulateFire(i: FireInputs): FireResult {
  const fiNumber = i.annualExpenses / (i.withdrawalRate / 100);
  const realReturn = (1 + i.annualReturn / 100) / (1 + i.inflation / 100) - 1;
  const monthlyRate = Math.pow(1 + realReturn, 1 / 12) - 1;
  const horizonYears = Math.min(MAX_YEARS, Math.max(1, 100 - i.currentAge));

  let balance = i.currentSavings;
  let contributed = i.currentSavings;
  let monthsToFi: number | null = balance >= fiNumber ? 0 : null;

  const points: FirePoint[] = [
    { year: 0, age: i.currentAge, balance, contributed },
  ];

  for (let m = 1; m <= horizonYears * 12; m++) {
    balance = balance * (1 + monthlyRate) + i.monthlyContribution;
    contributed += i.monthlyContribution;
    if (monthsToFi === null && balance >= fiNumber) monthsToFi = m;
    if (m % 12 === 0) {
      points.push({
        year: m / 12,
        age: i.currentAge + m / 12,
        balance,
        contributed,
      });
    }
  }

  const yearsToFi = monthsToFi === null ? null : monthsToFi / 12;

  return {
    fiNumber,
    monthsToFi,
    yearsToFi,
    fiAge: yearsToFi === null ? null : i.currentAge + yearsToFi,
    progress: fiNumber > 0 ? i.currentSavings / fiNumber : 0,
    realReturn,
    points,
  };
}
