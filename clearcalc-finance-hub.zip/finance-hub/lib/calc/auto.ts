export interface AutoInputs {
  /** Sticker price before sales tax */
  price: number;
  /** Sales tax, percent */
  salesTax: number;
  /** Cash paid at signing if you finance */
  downPayment: number;
  /** Loan APR, percent */
  apr: number;
  termMonths: number;
  /** Expected annual return on the cash you keep, percent (after tax) */
  investReturn: number;
}

export interface AutoPoint {
  month: number;
  /** Cumulative interest paid on the loan */
  interest: number;
  /** Cumulative investment growth on the cash you kept */
  earnings: number;
  /** earnings minus interest */
  net: number;
}

export interface AutoResult {
  cashPrice: number;
  down: number;
  loanAmount: number;
  payment: number;
  totalInterest: number;
  totalEarnings: number;
  /** Positive: financing and investing ends ahead of paying cash */
  advantage: number;
  /** Month the invested cash would run out, if it does */
  runsOutMonth: number | null;
  points: AutoPoint[];
}

export function simulateAuto(i: AutoInputs): AutoResult {
  const cashPrice = i.price * (1 + i.salesTax / 100);
  const down = Math.min(Math.max(i.downPayment, 0), cashPrice);
  const loanAmount = cashPrice - down;
  const n = i.termMonths;
  const r = i.apr / 1200;
  const ri = i.investReturn / 1200;

  const payment =
    loanAmount <= 0
      ? 0
      : r === 0
        ? loanAmount / n
        : (loanAmount * r) / (1 - Math.pow(1 + r, -n));

  // The financed path keeps the loan amount invested and pays the loan from it.
  let loanBalance = loanAmount;
  let invested = loanAmount;
  let interest = 0;
  let earnings = 0;
  let runsOutMonth: number | null = null;

  const points: AutoPoint[] = [{ month: 0, interest: 0, earnings: 0, net: 0 }];

  for (let m = 1; m <= n; m++) {
    const monthInterest = loanBalance * r;
    interest += monthInterest;
    loanBalance = Math.max(0, loanBalance + monthInterest - payment);

    const monthEarn = invested * ri;
    earnings += monthEarn;
    invested = invested + monthEarn - payment;
    if (invested < -0.005 && runsOutMonth === null) runsOutMonth = m;

    points.push({ month: m, interest, earnings, net: earnings - interest });
  }

  return {
    cashPrice,
    down,
    loanAmount,
    payment,
    totalInterest: interest,
    totalEarnings: earnings,
    advantage: earnings - interest,
    runsOutMonth,
    points,
  };
}
