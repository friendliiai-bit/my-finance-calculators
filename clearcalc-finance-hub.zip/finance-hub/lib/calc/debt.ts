export interface DebtInputs {
  /** Balance you would move, dollars */
  balance: number;
  /** Length of the 0% promotional period, months */
  promoMonths: number;
  /** One-time transfer fee, percent of the amount moved */
  transferFeePct: number;
  /** What you pay every month on either path, dollars */
  monthlyPayment: number;
  /** APR that applies after the promotion ends, percent */
  postPromoApr: number;
  /** APR on the card you would otherwise keep paying, percent */
  currentApr: number;
}

export interface DebtPoint {
  month: number;
  offer: number;
  stay: number;
}

export interface DebtResult {
  fee: number;
  startBalance: number;
  /** Payment that clears the transferred balance exactly by the end of the promotion */
  paymentToClearPromo: number;
  balanceAtPromoEnd: number;
  /** Interest owed after the promotion on the remaining balance (estimate to payoff) */
  interestAfterPromo: number;
  offerPayoffMonths: number | null;
  stayPayoffMonths: number | null;
  offerInterest: number;
  stayInterest: number;
  offerTotalCost: number;
  stayTotalCost: number;
  /** Positive when the transfer costs less overall */
  netSavings: number;
  points: DebtPoint[];
}

interface Schedule {
  balances: number[];
  interest: number;
  payoffMonth: number | null;
}

const MAX_MONTHS = 600;

function runSchedule(
  start: number,
  payment: number,
  aprAt: (month: number) => number,
): Schedule {
  const balances = [start];
  let balance = start;
  let interest = 0;
  let payoffMonth: number | null = start <= 0.005 ? 0 : null;

  for (let m = 1; m <= MAX_MONTHS && balance > 0.005; m++) {
    const monthlyInterest = (balance * aprAt(m)) / 1200;
    interest += monthlyInterest;
    balance += monthlyInterest;
    balance -= Math.min(payment, balance);
    balances.push(Math.max(0, balance));
    if (balance <= 0.005) {
      payoffMonth = m;
      balance = 0;
      break;
    }
    // The payment does not even cover the interest: the debt is running away.
    if (balance > start * 3) break;
  }

  return { balances, interest, payoffMonth };
}

export function simulateDebt(i: DebtInputs): DebtResult {
  const fee = (i.balance * i.transferFeePct) / 100;
  const startBalance = i.balance + fee;

  const offer = runSchedule(startBalance, i.monthlyPayment, (m) =>
    m <= i.promoMonths ? 0 : i.postPromoApr,
  );
  const stay = runSchedule(i.balance, i.monthlyPayment, () => i.currentApr);

  const horizon = Math.min(
    120,
    Math.max(
      offer.payoffMonth ?? offer.balances.length - 1,
      stay.payoffMonth ?? stay.balances.length - 1,
      i.promoMonths,
    ),
  );

  const at = (s: Schedule, m: number) =>
    m < s.balances.length
      ? s.balances[m]
      : s.payoffMonth !== null
        ? 0
        : s.balances[s.balances.length - 1];

  const points: DebtPoint[] = [];
  for (let m = 0; m <= horizon; m++) {
    points.push({ month: m, offer: at(offer, m), stay: at(stay, m) });
  }

  const balanceAtPromoEnd = at(offer, i.promoMonths);

  // Interest charged after the promotion ends
  let interestAfterPromo = 0;
  {
    let bal = balanceAtPromoEnd;
    for (let m = 1; m <= MAX_MONTHS && bal > 0.005; m++) {
      const mi = (bal * i.postPromoApr) / 1200;
      interestAfterPromo += mi;
      bal += mi;
      bal -= Math.min(i.monthlyPayment, bal);
      if (bal > balanceAtPromoEnd * 3) break;
    }
  }

  const offerTotalCost = offer.interest + fee;
  const stayTotalCost = stay.interest;

  return {
    fee,
    startBalance,
    paymentToClearPromo: i.promoMonths > 0 ? startBalance / i.promoMonths : startBalance,
    balanceAtPromoEnd,
    interestAfterPromo,
    offerPayoffMonths: offer.payoffMonth,
    stayPayoffMonths: stay.payoffMonth,
    offerInterest: offer.interest,
    stayInterest: stay.interest,
    offerTotalCost,
    stayTotalCost,
    netSavings: stayTotalCost - offerTotalCost,
    points,
  };
}
