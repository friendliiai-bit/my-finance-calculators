import type { CalcKey } from "./calculators";

export interface Affiliate {
  id: string;
  /** Brand shown on the card */
  partner: string;
  headline: string;
  blurb: string;
  cta: string;
  href: string;
}

/**
 * Each card links to the partner's public homepage until you set the matching
 * environment variable to your own tracked affiliate URL, for example:
 *
 *   AFFILIATE_FIRE_EMPOWER=https://your-network.example/click?id=123
 *
 * The variables are read on the server at build time. Only keep partners whose
 * affiliate programs you have actually joined, and edit the copy to match their terms.
 */
function link(envKey: string, fallback: string): string {
  return process.env[envKey] || fallback;
}

export const AFFILIATES: Record<CalcKey, Affiliate[]> = {
  fire: [
    {
      id: "fire-empower",
      partner: "Empower",
      headline: "Track net worth in one place",
      blurb:
        "Link your accounts to see your real savings and portfolio, then check them against your FI number.",
      cta: "See the free dashboard",
      href: link("AFFILIATE_FIRE_EMPOWER", "https://www.empower.com"),
    },
    {
      id: "fire-betterment",
      partner: "Betterment",
      headline: "Automate monthly investing",
      blurb:
        "Set a recurring contribution and let a diversified portfolio be rebalanced for you.",
      cta: "Explore automated investing",
      href: link("AFFILIATE_FIRE_BETTERMENT", "https://www.betterment.com"),
    },
    {
      id: "fire-fidelity",
      partner: "Fidelity",
      headline: "Low-cost index funds",
      blurb:
        "Fees quietly shave your return. Compare broad index funds before you pick where to invest.",
      cta: "Compare index funds",
      href: link("AFFILIATE_FIRE_FIDELITY", "https://www.fidelity.com"),
    },
  ],
  debt: [
    {
      id: "debt-nerdwallet",
      partner: "NerdWallet",
      headline: "Compare 0% balance transfer cards",
      blurb:
        "Look at promotional length and transfer fee side by side, then run the winner through the simulator.",
      cta: "Compare cards",
      href: link("AFFILIATE_DEBT_NERDWALLET", "https://www.nerdwallet.com"),
    },
    {
      id: "debt-creditkarma",
      partner: "Credit Karma",
      headline: "Check your score before you apply",
      blurb:
        "The best transfer offers usually go to good credit. See where you stand first and avoid needless inquiries.",
      cta: "Check your credit",
      href: link("AFFILIATE_DEBT_CREDITKARMA", "https://www.creditkarma.com"),
    },
    {
      id: "debt-ynab",
      partner: "YNAB",
      headline: "Budget the payment you need",
      blurb:
        "Turn the monthly amount from the simulator into a line in your budget so the deadline holds.",
      cta: "Try the budgeting app",
      href: link("AFFILIATE_DEBT_YNAB", "https://www.ynab.com"),
    },
  ],
  mortgage: [
    {
      id: "mortgage-rocket",
      partner: "Rocket Mortgage",
      headline: "See what a refinance could do",
      blurb:
        "If today's rates are below yours, a lower rate and extra payments can work together.",
      cta: "Get refinance quotes",
      href: link("AFFILIATE_MORTGAGE_ROCKET", "https://www.rocketmortgage.com"),
    },
    {
      id: "mortgage-lendingtree",
      partner: "LendingTree",
      headline: "Compare lenders in one request",
      blurb:
        "Rates and fees vary by lender. Compare several offers before you commit to a new loan.",
      cta: "Compare mortgage offers",
      href: link("AFFILIATE_MORTGAGE_LENDINGTREE", "https://www.lendingtree.com"),
    },
    {
      id: "mortgage-ally",
      partner: "Ally",
      headline: "Fund an emergency cushion first",
      blurb:
        "Before sending extra cash to your mortgage, keep a safety net somewhere you can reach it.",
      cta: "Explore savings accounts",
      href: link("AFFILIATE_MORTGAGE_ALLY", "https://www.ally.com"),
    },
  ],
  tax: [
    {
      id: "tax-turbotax",
      partner: "TurboTax",
      headline: "File with Schedule C support",
      blurb:
        "Guided filing for freelancers and side hustlers, including self-employment tax and deductions.",
      cta: "See self-employed filing",
      href: link("AFFILIATE_TAX_TURBOTAX", "https://turbotax.intuit.com"),
    },
    {
      id: "tax-quickbooks",
      partner: "QuickBooks",
      headline: "Track expenses all year",
      blurb:
        "Categorize business spending as it happens so your deductions are ready when quarterly payments are due.",
      cta: "Explore bookkeeping",
      href: link("AFFILIATE_TAX_QUICKBOOKS", "https://quickbooks.intuit.com"),
    },
    {
      id: "tax-fidelity",
      partner: "Fidelity",
      headline: "Open a solo 401(k) or SEP-IRA",
      blurb:
        "Retirement contributions reduce your taxable profit. Compare plan options for one-person businesses.",
      cta: "Compare retirement plans",
      href: link("AFFILIATE_TAX_FIDELITY", "https://www.fidelity.com"),
    },
  ],
  auto: [
    {
      id: "auto-capitalone",
      partner: "Capital One",
      headline: "Pre-qualify before you shop",
      blurb:
        "Know your rate before you walk into the dealership, then plug it into the APR slider.",
      cta: "See auto financing",
      href: link("AFFILIATE_AUTO_CAPITALONE", "https://www.capitalone.com/cars/"),
    },
    {
      id: "auto-lendingtree",
      partner: "LendingTree",
      headline: "Compare auto loan rates",
      blurb:
        "A single point of APR changes the verdict on this page. Compare lenders before you sign.",
      cta: "Compare auto loans",
      href: link("AFFILIATE_AUTO_LENDINGTREE", "https://www.lendingtree.com"),
    },
    {
      id: "auto-thezebra",
      partner: "The Zebra",
      headline: "Price the insurance too",
      blurb:
        "Insurance is part of the true monthly cost of any car. Compare quotes before you commit.",
      cta: "Compare insurance quotes",
      href: link("AFFILIATE_AUTO_THEZEBRA", "https://www.thezebra.com"),
    },
  ],
};
