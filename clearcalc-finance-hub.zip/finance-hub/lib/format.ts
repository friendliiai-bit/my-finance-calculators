const usdFmt = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

const usdCentsFmt = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/** Whole dollars, never "-$0". */
export function usd(n: number): string {
  return usdFmt.format(Math.abs(n) < 0.5 ? 0 : n);
}

export function usdCents(n: number): string {
  return usdCentsFmt.format(Math.abs(n) < 0.005 ? 0 : n);
}

function trim(x: number): string {
  return x >= 100 ? x.toFixed(0) : x.toFixed(1).replace(/\.0$/, "");
}

/** $1.2M, $48K, $950 */
export function usdCompact(n: number): string {
  const a = Math.abs(n);
  const sign = n < 0 && a >= 0.5 ? "-" : "";
  if (a >= 1e6) return `${sign}$${trim(a / 1e6)}M`;
  if (a >= 1e3) return `${sign}$${trim(a / 1e3)}K`;
  return `${sign}$${Math.round(a)}`;
}

export function pct(n: number, digits = 1): string {
  return `${n.toFixed(digits)}%`;
}

/** 87 months becomes "7 yr 3 mo" */
export function formatDuration(months: number): string {
  const total = Math.round(months);
  const y = Math.floor(total / 12);
  const m = total % 12;
  if (y === 0) return `${m} mo`;
  if (m === 0) return `${y} yr`;
  return `${y} yr ${m} mo`;
}

export function formatYears(years: number): string {
  return `${years.toFixed(1)} years`;
}
