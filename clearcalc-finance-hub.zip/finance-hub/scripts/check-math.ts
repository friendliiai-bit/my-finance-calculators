import { simulateFire } from "../lib/calc/fire";
import { simulateDebt } from "../lib/calc/debt";
import { amortize, monthlyPayment, simulateMortgage } from "../lib/calc/mortgage";
import { simulateAuto } from "../lib/calc/auto";
import { estimateTax, federalIncomeTax } from "../lib/calc/tax";

let failures = 0;
function check(name: string, actual: number, expected: number, tol = 0.01) {
  const ok = Math.abs(actual - expected) <= tol;
  if (!ok) failures++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}: got ${actual.toFixed(4)}, expected ${expected}`);
}

// Mortgage: textbook $200k, 6%, 30 years
check("mortgage payment", monthlyPayment(200000, 6, 360), 1199.1, 0.01);
const base = amortize(200000, 6, 360, 0, 0);
check("mortgage months", base.months, 360, 0);
check("mortgage total interest", base.interest, 231676.38, 1);
check("zero-rate payment", monthlyPayment(120000, 0, 120), 1000, 0.0001);

// Federal brackets: hand-computed from the 2026 bracket tables (Rev. Proc. 2025-32)
check("fed tax single $68,900", federalIncomeTax(68900, "single"), 9870, 0.5);
check("fed tax single $200,000", federalIncomeTax(200000, "single"), 40598, 1);
check("fed tax MFJ $200,000", federalIncomeTax(200000, "mfj"), 33424, 1);
// HOH $100,000 taxable: 1,770 + 5,970 + 7,161
check("fed tax HOH $100,000", federalIncomeTax(100000, "hoh"), 14901, 0.5);

// Self-employment tax: $10,000 profit, no wages
{
  const r = estimateTax({
    status: "single", w2Income: 0, sideRevenue: 10000, sideExpenses: 0,
    stateRate: 0, retirementPct: 0,
  });
  check("SE tax on $10k", r.seTax, 10000 * 0.9235 * 0.153, 0.01);
  check("half-SE deduction", r.halfSeDeduction, (10000 * 0.9235 * 0.153) / 2, 0.01);
}

// Wage base: $150k of wages leaves $34.5k of room for the 12.4% Social Security portion.
{
  const r = estimateTax({
    status: "single", w2Income: 150000, sideRevenue: 50000, sideExpenses: 0,
    stateRate: 0, retirementPct: 0,
  });
  check("SE tax straddling the wage base", r.seTax, 0.124 * 34500 + 0.029 * 50000 * 0.9235, 0.01);
}
// Wages already above the base: Medicare only, plus 0.9% additional Medicare over $200k.
{
  const r = estimateTax({
    status: "single", w2Income: 250000, sideRevenue: 50000, sideExpenses: 0,
    stateRate: 0, retirementPct: 0,
  });
  check("SE tax above the wage base", r.seTax, 50000 * 0.9235 * (0.029 + 0.009), 0.01);
}
// QBI warning: shown at high income, not at the default income.
{
  const base = {
    status: "single" as const, sideRevenue: 20000, sideExpenses: 0,
    stateRate: 0, retirementPct: 0,
  };
  check("QBI caution at $300k wages", estimateTax({ ...base, w2Income: 300000 }).qbiMayBeLimited ? 1 : 0, 1, 0);
  check("no QBI caution at $85k wages", estimateTax({ ...base, w2Income: 85000 }).qbiMayBeLimited ? 1 : 0, 0, 0);
}

// Auto loan: when the investment return equals the APR, the two paths tie.
{
  const r = simulateAuto({
    price: 30000, salesTax: 0, downPayment: 0, apr: 6, termMonths: 60, investReturn: 6,
  });
  check("auto break-even at return == APR", r.advantage, 0, 0.01);
}

// Debt: paying (balance + fee) / promo months clears the offer exactly
{
  const d = simulateDebt({
    balance: 8000, promoMonths: 15, transferFeePct: 3, monthlyPayment: 8240 / 15,
    postPromoApr: 24.99, currentApr: 22.99,
  });
  check("debt balance at promo end", d.balanceAtPromoEnd, 0, 0.05);
  check("debt payoff months", d.offerPayoffMonths ?? -1, 15, 0);
}

// Defaults shown on the pages (quoted in the written guides)
const fire = simulateFire({
  currentAge: 30, currentSavings: 50000, monthlyContribution: 2000,
  annualReturn: 7, inflation: 2.5, annualExpenses: 48000, withdrawalRate: 4,
});
const fireMore = simulateFire({
  currentAge: 30, currentSavings: 50000, monthlyContribution: 2500,
  annualReturn: 7, inflation: 2.5, annualExpenses: 48000, withdrawalRate: 4,
});
console.log("\nFIRE defaults:", {
  fiNumber: fire.fiNumber,
  realReturn: +(fire.realReturn * 100).toFixed(2),
  yearsToFi: fire.yearsToFi && +fire.yearsToFi.toFixed(1),
  fiAge: fire.fiAge && +fire.fiAge.toFixed(1),
  yearsWithPlus500: fireMore.yearsToFi && +fireMore.yearsToFi.toFixed(1),
});

const m = simulateMortgage({
  balance: 320000, rate: 6.5, remainingYears: 27, extraMonthly: 300, annualLump: 0,
});
console.log("Mortgage defaults:", {
  payment: +m.payment.toFixed(2),
  standardMonths: m.standard.months,
  acceleratedMonths: m.accelerated.months,
  yearsSaved: +(m.monthsSaved / 12).toFixed(1),
  interestStandard: Math.round(m.standard.interest),
  interestSaved: Math.round(m.interestSaved),
});

const t = estimateTax({
  status: "single", w2Income: 85000, sideRevenue: 24000, sideExpenses: 4000,
  stateRate: 4.5, retirementPct: 0,
});
console.log("Tax defaults:", Object.fromEntries(
  Object.entries(t).filter(([k]) => !["segments", "curve"].includes(k))
    .map(([k, v]) => [k, typeof v === "number" ? +v.toFixed(3) : v]),
));

const a = simulateAuto({
  price: 38000, salesTax: 7, downPayment: 5000, apr: 6.9, termMonths: 60, investReturn: 5,
});
console.log("Auto defaults:", {
  loan: Math.round(a.loanAmount), payment: +a.payment.toFixed(2),
  interest: Math.round(a.totalInterest), earnings: Math.round(a.totalEarnings),
  advantage: Math.round(a.advantage), runsOut: a.runsOutMonth,
});

const d = simulateDebt({
  balance: 8000, promoMonths: 15, transferFeePct: 3, monthlyPayment: 450,
  postPromoApr: 24.99, currentApr: 22.99,
});
console.log("Debt defaults:", {
  fee: d.fee, needed: +d.paymentToClearPromo.toFixed(2),
  leftAtPromoEnd: Math.round(d.balanceAtPromoEnd),
  interestAfter: Math.round(d.interestAfterPromo),
  offerMonths: d.offerPayoffMonths, stayMonths: d.stayPayoffMonths,
  stayInterest: Math.round(d.stayInterest), net: Math.round(d.netSavings),
});

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log("\nAll math checks passed");
