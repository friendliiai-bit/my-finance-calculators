import { autoCopy } from "../content/auto";
import { debtCopy } from "../content/debt";
import { fireCopy } from "../content/fire";
import { mortgageCopy } from "../content/mortgage";
import { taxCopy } from "../content/tax";
import type { SeoCopy } from "../components/SeoContent";

const words = (s: string) => s.trim().split(/\s+/).filter(Boolean).length;

function count(copy: SeoCopy) {
  const body =
    words(copy.heading) +
    copy.intro.reduce((n, p) => n + words(p), 0) +
    copy.sections.reduce(
      (n, s) => n + words(s.heading) + s.body.reduce((m, p) => m + words(p), 0),
      0,
    );
  const faq = copy.faqs.reduce((n, f) => n + words(f.question) + words(f.answer), 0);
  return { article: body, faqs: faq, total: body + faq + words("Frequently asked questions") };
}

const pages = { fireCopy, debtCopy, mortgageCopy, taxCopy, autoCopy };
let low = 0;
for (const [name, copy] of Object.entries(pages)) {
  const c = count(copy);
  // The article alone must clear 800 words; the FAQ section is on top of that.
  if (c.article < 800) low++;
  console.log(
    `${name.padEnd(14)} article ${String(c.article).padStart(4)}  faqs ${String(c.faqs).padStart(4)}  total ${String(c.total).padStart(4)}  ${c.article >= 800 ? "OK" : "ARTICLE UNDER 800"}`,
  );
}
process.exit(low ? 1 : 0);
