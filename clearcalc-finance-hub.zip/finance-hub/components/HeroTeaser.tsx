"use client";

import Link from "next/link";
import { useState } from "react";
import { Slider } from "@/components/Slider";
import { usd } from "@/lib/format";

const RETURN = 7;
const INFLATION = 2.5;
const YEARS = 30;

function futureValue(monthly: number, annualPct: number, years: number) {
  const r = annualPct / 1200;
  const n = years * 12;
  return r === 0 ? monthly * n : monthly * ((Math.pow(1 + r, n) - 1) / r);
}

/** One live number on the home page: the compounding every calculator builds on. */
export function HeroTeaser() {
  const [monthly, setMonthly] = useState(500);
  const nominal = futureValue(monthly, RETURN, YEARS);
  const real = nominal / Math.pow(1 + INFLATION / 100, YEARS);
  const contributed = monthly * YEARS * 12;

  return (
    <div className="rounded-2xl border border-line bg-panel p-5 shadow-[0_1px_2px_rgb(20_35_59/0.06)] sm:p-6">
      <h2 className="font-display text-lg font-semibold leading-snug tracking-tight">
        What does a steady monthly habit become?
      </h2>
      <Slider
        label="Invested each month"
        value={monthly}
        min={50}
        max={3000}
        step={50}
        onChange={setMonthly}
        format={usd}
      />
      <div aria-live="polite" className="mt-2 border-t border-line pt-4">
        <p className="text-sm text-ink-soft">After {YEARS} years at {RETURN}% a year</p>
        <p className="mt-1 font-display text-[2.75rem] font-bold leading-none tracking-tight">
          {usd(nominal)}
        </p>
        <p className="mt-3 text-sm leading-relaxed text-ink-soft">
          That is {usd(real)} in today&apos;s buying power with {INFLATION}% inflation, from{" "}
          {usd(contributed)} of your own money.
        </p>
      </div>
      <Link
        href="/fire-calc"
        className="mt-5 inline-flex items-center rounded-lg bg-ink px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-brand-deep"
      >
        Plan your own timeline
      </Link>
    </div>
  );
}
