import type { Affiliate } from "@/lib/affiliates";

export function AffiliateSidebar({
  heading,
  items,
}: {
  heading: string;
  items: Affiliate[];
}) {
  return (
    <aside
      aria-labelledby="recs-heading"
      className="lg:sticky lg:top-24 lg:self-start"
    >
      <h2
        id="recs-heading"
        className="font-display text-lg font-semibold leading-tight tracking-tight"
      >
        {heading}
      </h2>
      <p className="mt-1 text-xs leading-relaxed text-muted">
        We may earn a commission if you sign up through these links, at no cost to
        you. It never changes the math on this page.
      </p>

      <ul className="mt-4 space-y-3">
        {items.map((a) => (
          <li
            key={a.id}
            className="border-l-4 border-brand bg-panel py-3.5 pl-4 pr-4 shadow-[0_1px_2px_rgb(20_35_59/0.06)]"
          >
            <p className="text-xs text-muted">Affiliate link from {a.partner}</p>
            <p className="mt-1 font-semibold leading-snug text-ink">
              {a.headline}
            </p>
            <p className="mt-1 text-sm leading-relaxed text-ink-soft">
              {a.blurb}
            </p>
            <a
              href={a.href}
              target="_blank"
              rel="sponsored noopener noreferrer"
              className="mt-3 inline-flex items-center rounded-lg bg-ink px-3.5 py-2 text-sm font-semibold text-white transition-colors hover:bg-brand-deep"
            >
              {a.cta}
              <span className="sr-only"> on {a.partner} (opens in a new tab)</span>
            </a>
          </li>
        ))}
      </ul>
    </aside>
  );
}
