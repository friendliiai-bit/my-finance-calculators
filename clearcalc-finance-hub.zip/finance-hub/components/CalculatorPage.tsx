import type { ReactNode } from "react";
import { AffiliateSidebar } from "@/components/AffiliateSidebar";
import { SeoContent, type SeoCopy } from "@/components/SeoContent";
import type { Affiliate } from "@/lib/affiliates";
import type { CalcMeta } from "@/lib/calculators";
import { SITE } from "@/lib/site";

export function CalculatorPage({
  calc,
  copy,
  affiliates,
  children,
}: {
  calc: CalcMeta;
  copy: SeoCopy;
  affiliates: Affiliate[];
  children: ReactNode;
}) {
  const appLd = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: calc.title,
    url: `${SITE.url}${calc.href}`,
    description: calc.metaDescription,
    applicationCategory: "FinanceApplication",
    operatingSystem: "Any",
    offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
  };

  return (
    <>
      <header className="page-head border-b border-line">
        <div className="mx-auto max-w-[1200px] px-4 pb-8 pt-10 sm:px-6 sm:pt-14">
          <h1 className="max-w-3xl font-display text-[2.25rem] font-bold leading-[1.05] tracking-[-0.025em] sm:text-5xl">
            {calc.title}
          </h1>
          <p className="mt-4 max-w-2xl text-lg leading-relaxed text-ink-soft">
            {calc.tagline}
          </p>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1200px] gap-8 px-4 pt-8 sm:px-6 lg:grid-cols-[minmax(0,1fr)_17.5rem]">
        <div className="min-w-0">{children}</div>
        <AffiliateSidebar
          heading="Tools that pair with this"
          items={affiliates}
        />
      </div>

      <SeoContent copy={copy} />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(appLd) }}
      />
    </>
  );
}
