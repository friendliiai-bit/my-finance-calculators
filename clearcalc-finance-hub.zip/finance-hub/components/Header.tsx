"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { CALCULATOR_LIST } from "@/lib/calculators";
import { SITE } from "@/lib/site";

function Logo() {
  return (
    <Link
      href="/"
      className="flex items-center gap-2.5 font-display text-xl font-bold tracking-tight text-ink"
      aria-label={`${SITE.name} home`}
    >
      <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
        <rect width="28" height="28" rx="7" fill="#14233b" />
        <path d="M7 9h8M7 14h14M7 19h10" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" />
        <circle cx="21" cy="9" r="2" fill="#2a78d6" />
      </svg>
      {SITE.name}
    </Link>
  );
}

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-panel/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-[1200px] items-center justify-between gap-6 px-4 sm:px-6">
        <Logo />

        <nav aria-label="Calculators" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {CALCULATOR_LIST.map((c) => {
              const active = pathname === c.href;
              return (
                <li key={c.key}>
                  <Link
                    href={c.href}
                    aria-current={active ? "page" : undefined}
                    className={`relative rounded-md px-3 py-2 text-sm font-medium transition-colors hover:text-ink ${
                      active ? "text-ink" : "text-ink-soft"
                    }`}
                  >
                    {c.navLabel}
                    {active ? (
                      <span className="absolute inset-x-3 -bottom-[15px] h-0.5 bg-brand" aria-hidden="true" />
                    ) : null}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <button
          type="button"
          className="inline-flex items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm font-medium text-ink lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          onClick={() => setOpen((o) => !o)}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
          Calculators
        </button>
      </div>

      {open ? (
        <nav id="mobile-nav" aria-label="Calculators" className="border-t border-line bg-panel lg:hidden">
          <ul className="mx-auto max-w-[1200px] px-4 py-2 sm:px-6">
            {CALCULATOR_LIST.map((c) => {
              const active = pathname === c.href;
              return (
                <li key={c.key} className="border-b border-line last:border-b-0">
                  <Link
                    href={c.href}
                    aria-current={active ? "page" : undefined}
                    onClick={() => setOpen(false)}
                    className={`flex items-baseline justify-between py-3 text-base font-medium ${
                      active ? "text-brand-deep" : "text-ink"
                    }`}
                  >
                    {c.title}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      ) : null}
    </header>
  );
}
