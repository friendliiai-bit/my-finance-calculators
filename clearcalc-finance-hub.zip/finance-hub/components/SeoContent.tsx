export interface SeoCopy {
  heading: string;
  intro: string[];
  sections: { heading: string; body: string[] }[];
  faqs: { question: string; answer: string }[];
}

export function SeoContent({ copy }: { copy: SeoCopy }) {
  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: copy.faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  return (
    <section
      aria-labelledby="guide-heading"
      className="mx-auto max-w-[1200px] px-4 pb-20 pt-14 sm:px-6"
    >
      <article className="guide max-w-[42rem]">
        <h2 id="guide-heading">{copy.heading}</h2>
        {copy.intro.map((p, i) => (
          <p key={i}>{p}</p>
        ))}

        {copy.sections.map((s) => (
          <div key={s.heading}>
            <h2>{s.heading}</h2>
            {s.body.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        ))}

        <h2>Frequently asked questions</h2>
        <div>
          {copy.faqs.map((f) => (
            <div key={f.question} className="faq-item">
              <h3>{f.question}</h3>
              <p>{f.answer}</p>
            </div>
          ))}
        </div>
      </article>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqLd) }}
      />
    </section>
  );
}
