"use client";

import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  LabelList,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Callout } from "@/components/Callout";
import { ChartFrame } from "@/components/ChartFrame";
import { ChartTooltip } from "@/components/chart-parts";
import { Slider } from "@/components/Slider";
import { Stat, StatGrid } from "@/components/Stat";
import { Workbench } from "@/components/Workbench";
import { axisTick, C } from "@/lib/chart";
import { formatDuration, usd, usdCents, usdCompact } from "@/lib/format";
import { simulateMortgage, type MortgageInputs } from "@/lib/calc/mortgage";

const DEFAULTS: MortgageInputs = {
  balance: 320000,
  rate: 6.5,
  remainingYears: 27,
  extraMonthly: 300,
  annualLump: 0,
};

const fmtRate = (n: number) => `${+n.toFixed(3)}%`;

export function MortgagePayoff() {
  const [v, setV] = useState<MortgageInputs>(DEFAULTS);
  const set = (key: keyof MortgageInputs) => (n: number) =>
    setV((s) => ({ ...s, [key]: n }));

  const r = useMemo(() => simulateMortgage(v), [v]);
  const noExtra = v.extraMonthly === 0 && v.annualLump === 0;

  // Round tick marks (0, 5, 10 ...) instead of the chart's automatic 7-year steps.
  const lastYear = r.points[r.points.length - 1].year;
  const tickStep = lastYear <= 10 ? 1 : lastYear <= 20 ? 2 : 5;
  const yearTicks = Array.from({ length: Math.floor(lastYear / tickStep) + 1 }, (_, i) => i * tickStep);

  const interestBars = [
    { name: "Current schedule", interest: r.standard.interest, fill: C.orange },
    { name: "With extra payments", interest: r.accelerated.interest, fill: C.blue },
  ];

  return (
    <Workbench
      controlsLabel="Your mortgage"
      controls={
        <>
          <Slider label="Loan balance" value={v.balance} min={50000} max={1000000} step={5000} onChange={set("balance")} format={usd} />
          <Slider label="Interest rate" value={v.rate} min={2} max={9} step={0.125} onChange={set("rate")} format={fmtRate} />
          <Slider label="Years remaining" value={v.remainingYears} min={5} max={30} onChange={set("remainingYears")} format={(n) => `${n} years`} />
          <Slider label="Extra each month" value={v.extraMonthly} min={0} max={2000} step={25} onChange={set("extraMonthly")} format={usd} />
          <Slider label="Extra once a year" value={v.annualLump} min={0} max={20000} step={500} onChange={set("annualLump")} format={usd} hint="A bonus or tax refund, applied every 12th month." />
        </>
      }
      results={
        <>
          <StatGrid>
            <Stat
              label="Monthly payment"
              value={usdCents(r.payment)}
              note="Principal and interest only"
            />
            <Stat
              label="Paid off in"
              value={formatDuration(r.accelerated.months)}
              note={`Now: ${formatDuration(r.standard.months)}`}
              emphasis
            />
            <Stat
              label="Interest saved"
              value={usd(r.interestSaved)}
              note={`Of ${usd(r.standard.interest)} on the current path`}
              emphasis
            />
            <Stat
              label="Time saved"
              value={formatDuration(r.monthsSaved)}
              note="Off the end of the loan"
            />
          </StatGrid>

          {noExtra ? (
            <Callout tone="neutral" title="Add an extra payment to see the effect.">
              Try $200 a month, or a yearly lump sum from a bonus or refund.
            </Callout>
          ) : (
            <Callout tone="neutral" title={`Each extra dollar earns your loan rate of ${fmtRate(v.rate)}, with no market risk.`}>
              Confirm your loan has no prepayment penalty, and tell your servicer to
              apply the extra amount to principal.
            </Callout>
          )}

          <ChartFrame
            title="Remaining balance by year"
            subtitle="Extra principal makes the blue line fall faster, so you finish earlier."
            legend={[
              { label: "With extra payments", color: C.blue },
              { label: "Current schedule", color: C.orange },
            ]}
            height={300}
            table={{
              headers: ["Year", "Current schedule", "With extra payments"],
              rows: r.points.map((p) => [p.year, usd(p.standard), usd(p.accelerated)]),
            }}
          >
            <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 640, height: 300 }}>
              <LineChart data={r.points} margin={{ top: 12, right: 16, bottom: 4, left: 0 }}>
                <CartesianGrid vertical={false} stroke={C.grid} />
                <XAxis dataKey="year" type="number" domain={[0, "dataMax"]} ticks={yearTicks} tick={axisTick} tickLine={false} axisLine={{ stroke: C.axis }} />
                <YAxis domain={[0, "auto"]} tick={axisTick} tickLine={false} axisLine={false} width={56} tickFormatter={(n: number) => usdCompact(n)} />
                <Tooltip cursor={{ stroke: C.axis }} content={<ChartTooltip valueFormat={usd} labelFormat={(l) => `Year ${l}`} />} />
                <Line type="monotone" dataKey="standard" name="Current schedule" stroke={C.orange} strokeWidth={2} dot={false} activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }} isAnimationActive={false} />
                <Line type="monotone" dataKey="accelerated" name="With extra payments" stroke={C.blue} strokeWidth={2} dot={false} activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartFrame>

          <ChartFrame
            title="Total interest over the life of the loan"
            subtitle="Lifetime interest on each path, from today's balance."
            height={150}
            table={{
              headers: ["Path", "Total interest"],
              rows: interestBars.map((b) => [b.name, usd(b.interest)]),
            }}
          >
            <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 640, height: 150 }}>
              <BarChart data={interestBars} layout="vertical" margin={{ top: 4, right: 72, bottom: 0, left: 8 }}>
                <XAxis type="number" hide domain={[0, "dataMax"]} />
                <YAxis type="category" dataKey="name" width={132} tick={{ fill: C.ink, fontSize: 13 }} tickLine={false} axisLine={{ stroke: C.axis }} />
                <Tooltip cursor={false} content={<ChartTooltip valueFormat={usd} />} />
                <Bar dataKey="interest" name="Total interest" barSize={24} radius={[0, 4, 4, 0]} isAnimationActive={false}>
                  {interestBars.map((b) => (
                    <Cell key={b.name} fill={b.fill} />
                  ))}
                  <LabelList dataKey="interest" position="right" formatter={(n: unknown) => usdCompact(Number(n))} fill={C.ink} fontSize={13} fontWeight={600} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>

          <p className="text-xs leading-relaxed text-muted">
            Assumes a fixed rate, payments made on schedule and no escrow in the
            figures shown. Enter your current balance and remaining term for the
            most accurate result. This is an estimate, not financial advice.
          </p>
        </>
      }
    />
  );
}
