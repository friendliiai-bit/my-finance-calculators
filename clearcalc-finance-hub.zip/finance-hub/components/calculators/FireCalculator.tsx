"use client";

import { useMemo, useState } from "react";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Callout } from "@/components/Callout";
import { ChartFrame } from "@/components/ChartFrame";
import { ChartTooltip, endLabel } from "@/components/chart-parts";
import { Slider } from "@/components/Slider";
import { Stat, StatGrid } from "@/components/Stat";
import { Workbench } from "@/components/Workbench";
import { axisTick, C } from "@/lib/chart";
import { formatDuration, pct, usd, usdCompact } from "@/lib/format";
import { simulateFire, type FireInputs } from "@/lib/calc/fire";

const DEFAULTS: FireInputs = {
  currentAge: 30,
  currentSavings: 50000,
  monthlyContribution: 2000,
  annualReturn: 7,
  inflation: 2.5,
  annualExpenses: 48000,
  withdrawalRate: 4,
};

export function FireCalculator() {
  const [v, setV] = useState<FireInputs>(DEFAULTS);
  const set = (key: keyof FireInputs) => (n: number) =>
    setV((s) => ({ ...s, [key]: n }));

  const result = useMemo(() => simulateFire(v), [v]);
  const boosted = useMemo(
    () => simulateFire({ ...v, monthlyContribution: v.monthlyContribution + 500 }),
    [v],
  );

  const chartYears =
    result.yearsToFi !== null
      ? Math.min(60, Math.max(10, Math.ceil(result.yearsToFi) + 6))
      : result.points.length - 1;
  const data = result.points.filter((p) => p.year <= chartYears);

  const insight = (() => {
    if (result.monthsToFi === 0) {
      return (
        <Callout tone="good" title="You have already reached your FI number.">
          Your savings cover {usd(v.annualExpenses)} a year at a{" "}
          {pct(v.withdrawalRate)} withdrawal rate. Stress-test it with a lower
          rate or higher spending.
        </Callout>
      );
    }
    if (result.yearsToFi === null) {
      return (
        <Callout tone="warn" title="Not within 60 years at this pace.">
          Raise your monthly contribution, trim annual expenses or accept a
          higher withdrawal rate to bring the target within reach.
        </Callout>
      );
    }
    if (boosted.yearsToFi !== null && result.yearsToFi - boosted.yearsToFi >= 0.1) {
      const saved = result.yearsToFi - boosted.yearsToFi;
      return (
        <Callout tone="neutral" title={`Adding $500 a month gets you there ${saved.toFixed(1)} years sooner.`}>
          Financial independence moves from age {Math.ceil(result.fiAge ?? 0)} to
          about age {Math.ceil(boosted.fiAge ?? 0)}.
        </Callout>
      );
    }
    return null;
  })();

  return (
    <Workbench
      controlsLabel="Your plan"
      controls={
        <>
          <Slider label="Current age" value={v.currentAge} min={18} max={65} onChange={set("currentAge")} format={(n) => `${n}`} />
          <Slider label="Savings today" value={v.currentSavings} min={0} max={1000000} step={5000} onChange={set("currentSavings")} format={usd} />
          <Slider label="Monthly contribution" value={v.monthlyContribution} min={0} max={10000} step={100} onChange={set("monthlyContribution")} format={usd} hint="Kept constant in today's dollars." />
          <Slider label="Expected annual return" value={v.annualReturn} min={0} max={12} step={0.1} onChange={set("annualReturn")} format={(n) => pct(n)} />
          <Slider label="Inflation" value={v.inflation} min={0} max={6} step={0.1} onChange={set("inflation")} format={(n) => pct(n)} />
          <Slider label="Annual spending in retirement" value={v.annualExpenses} min={12000} max={200000} step={1000} onChange={set("annualExpenses")} format={usd} />
          <Slider label="Withdrawal rate" value={v.withdrawalRate} min={2.5} max={6} step={0.1} onChange={set("withdrawalRate")} format={(n) => pct(n)} hint="4% is the classic starting point. Lower is more cautious." />
        </>
      }
      results={
        <>
          <StatGrid>
            <Stat
              label="FI number"
              value={usd(result.fiNumber)}
              note={`${usd(v.annualExpenses)} ÷ ${pct(v.withdrawalRate)}`}
              emphasis
            />
            <Stat
              label="Time to FI"
              value={result.monthsToFi === null ? "60+ years" : result.monthsToFi === 0 ? "Now" : formatDuration(result.monthsToFi)}
              note={`Real return ${pct(result.realReturn * 100)} after inflation`}
              emphasis
            />
            <Stat
              label="Age at FI"
              value={result.fiAge === null ? "Not reached" : `${Math.ceil(result.fiAge)}`}
            />
            <Stat
              label="Saved so far"
              value={`${Math.round(result.progress * 100)}%`}
              note={`${usd(v.currentSavings)} of ${usdCompact(result.fiNumber)}`}
            />
          </StatGrid>

          {insight}

          <ChartFrame
            title="Portfolio growth in today's dollars"
            subtitle="The line marks your FI number. Where the blue area crosses it, work becomes optional."
            legend={[
              { label: "Portfolio value", color: C.blue },
              { label: "Total contributed", color: C.orange },
            ]}
            height={320}
            table={{
              headers: ["Age", "Portfolio value", "Total contributed"],
              rows: data.map((p) => [p.age, usd(p.balance), usd(p.contributed)]),
            }}
          >
            <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 640, height: 320 }}>
              <ComposedChart data={data} margin={{ top: 12, right: 64, bottom: 4, left: 0 }}>
                <CartesianGrid vertical={false} stroke={C.grid} />
                <XAxis
                  dataKey="age"
                  type="number"
                  domain={["dataMin", "dataMax"]}
                  tick={axisTick}
                  tickLine={false}
                  axisLine={{ stroke: C.axis }}
                  tickFormatter={(n: number) => `${Math.round(n)}`}
                />
                <YAxis
                  domain={[0, (max: number) => Math.max(max, result.fiNumber * 1.1)]}
                  tick={axisTick}
                  tickLine={false}
                  axisLine={false}
                  width={56}
                  tickFormatter={(n: number) => usdCompact(n)}
                />
                <Tooltip
                  cursor={{ stroke: C.axis }}
                  content={<ChartTooltip valueFormat={usd} labelFormat={(l) => `Age ${Math.round(Number(l))}`} />}
                />
                <ReferenceLine
                  y={result.fiNumber}
                  stroke={C.ink}
                  strokeWidth={1.5}
                  label={{ value: `FI number ${usdCompact(result.fiNumber)}`, position: "insideTopLeft", fill: C.ink, fontSize: 12, fontWeight: 600 }}
                />
                <Area
                  type="monotone"
                  dataKey="contributed"
                  name="Total contributed"
                  stroke={C.orange}
                  strokeWidth={2}
                  fill={C.orange}
                  fillOpacity={0.1}
                  dot={false}
                  activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }}
                  label={endLabel(data.length - 1, usdCompact)}
                  isAnimationActive={false}
                />
                <Area
                  type="monotone"
                  dataKey="balance"
                  name="Portfolio value"
                  stroke={C.blue}
                  strokeWidth={2}
                  fill={C.blue}
                  fillOpacity={0.1}
                  dot={false}
                  activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }}
                  label={endLabel(data.length - 1, usdCompact)}
                  isAnimationActive={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </ChartFrame>

          <p className="text-xs leading-relaxed text-muted">
            Contributions are added monthly and grow at the real (after-inflation)
            return. Taxes, fees, Social Security and changing spending are not
            modeled. This is an estimate, not financial advice.
          </p>
        </>
      }
    />
  );
}
