"use client";

import { useMemo, useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Callout } from "@/components/Callout";
import { ChartFrame } from "@/components/ChartFrame";
import { ChartTooltip } from "@/components/chart-parts";
import { Slider } from "@/components/Slider";
import { Stat, StatGrid } from "@/components/Stat";
import { Workbench } from "@/components/Workbench";
import { axisTick, C } from "@/lib/chart";
import { simulateDebt, type DebtInputs } from "@/lib/calc/debt";
import { formatDuration, pct, usd, usdCompact } from "@/lib/format";

const DEFAULTS: DebtInputs = {
  balance: 8000,
  promoMonths: 15,
  transferFeePct: 3,
  monthlyPayment: 450,
  postPromoApr: 24.99,
  currentApr: 22.99,
};

export function DebtPayoff() {
  const [v, setV] = useState<DebtInputs>(DEFAULTS);
  const set = (key: keyof DebtInputs) => (n: number) =>
    setV((s) => ({ ...s, [key]: n }));

  const r = useMemo(() => simulateDebt(v), [v]);

  const step = r.points.length <= 25 ? 3 : r.points.length <= 49 ? 6 : 12;
  const ticks = r.points.filter((p) => p.month % step === 0).map((p) => p.month);
  const clearsInPromo = v.monthlyPayment + 0.005 >= r.paymentToClearPromo;

  const verdict = clearsInPromo ? (
    <Callout tone="good" title="This payment clears the balance inside the 0% period.">
      You would be debt-free in {formatDuration(r.offerPayoffMonths ?? v.promoMonths)}.
      The {usd(r.fee)} transfer fee is your only cost.
    </Callout>
  ) : r.offerPayoffMonths === null ? (
    <Callout tone="warn" title="At this payment the transferred balance never clears.">
      The payment does not outrun interest once the 0% period ends. Raise it to
      at least {usd(r.paymentToClearPromo)} a month.
    </Callout>
  ) : (
    <Callout tone="warn" title={`You would still owe ${usd(r.balanceAtPromoEnd)} when the 0% period ends.`}>
      Pay about {usd(r.paymentToClearPromo)} a month to finish on time. As things
      stand, the rest costs roughly {usd(r.interestAfterPromo)} in interest at{" "}
      {pct(v.postPromoApr, 2)} APR.
    </Callout>
  );

  const donePath = (months: number | null) =>
    months === null ? "Not paid off" : formatDuration(months);

  return (
    <Workbench
      controlsLabel="The offer and your budget"
      controls={
        <>
          <Slider label="Balance to transfer" value={v.balance} min={500} max={50000} step={100} onChange={set("balance")} format={usd} />
          <Slider label="0% period" value={v.promoMonths} min={6} max={24} onChange={set("promoMonths")} format={(n) => `${n} months`} />
          <Slider label="Transfer fee" value={v.transferFeePct} min={0} max={5} step={0.5} onChange={set("transferFeePct")} format={(n) => pct(n)} />
          <Slider label="Monthly payment" value={v.monthlyPayment} min={50} max={2000} step={10} onChange={set("monthlyPayment")} format={usd} hint="Applied the same way on both paths." />
          <Slider label="APR after the 0% period" value={v.postPromoApr} min={10} max={36} step={0.25} onChange={set("postPromoApr")} format={(n) => pct(n, 2)} />
          <Slider label="APR on your current card" value={v.currentApr} min={0} max={36} step={0.25} onChange={set("currentApr")} format={(n) => pct(n, 2)} />
        </>
      }
      results={
        <>
          <StatGrid>
            <Stat
              label="Transfer fee"
              value={usd(r.fee)}
              note={`${pct(v.transferFeePct)} of ${usd(v.balance)}`}
            />
            <Stat
              label="Owed when 0% ends"
              value={usd(r.balanceAtPromoEnd)}
              note={`After ${v.promoMonths} payments`}
            />
            <Stat
              label="Debt-free with transfer"
              value={donePath(r.offerPayoffMonths)}
              note={`Staying put: ${donePath(r.stayPayoffMonths)}`}
              emphasis
            />
            <Stat
              label="Net saving after fee"
              value={usd(r.netSavings)}
              note="Interest avoided minus the fee"
              emphasis
            />
          </StatGrid>

          {verdict}

          <ChartFrame
            title="Balance month by month"
            subtitle="Same monthly payment on both paths. The dashed marker shows where the 0% period ends."
            legend={[
              { label: "Transfer to 0% card", color: C.blue },
              { label: "Stay on current card", color: C.orange },
            ]}
            height={300}
            table={{
              headers: ["Month", "With transfer", "Current card"],
              rows: r.points.map((p) => [p.month, usd(p.offer), usd(p.stay)]),
            }}
          >
            <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 640, height: 300 }}>
              <LineChart data={r.points} margin={{ top: 12, right: 16, bottom: 4, left: 0 }}>
                <CartesianGrid vertical={false} stroke={C.grid} />
                <XAxis
                  dataKey="month"
                  type="number"
                  domain={[0, "dataMax"]}
                  ticks={ticks}
                  tick={axisTick}
                  tickLine={false}
                  axisLine={{ stroke: C.axis }}
                />
                <YAxis
                  domain={[0, "auto"]}
                  tick={axisTick}
                  tickLine={false}
                  axisLine={false}
                  width={52}
                  tickFormatter={(n: number) => usdCompact(n)}
                />
                <Tooltip
                  cursor={{ stroke: C.axis }}
                  content={<ChartTooltip valueFormat={usd} labelFormat={(l) => `Month ${l}`} />}
                />
                <ReferenceLine
                  x={v.promoMonths}
                  stroke={C.inkSoft}
                  strokeDasharray="4 4"
                  label={{ value: "0% ends", position: "insideTopRight", fill: C.inkSoft, fontSize: 12 }}
                />
                <Line type="monotone" dataKey="stay" name="Current card" stroke={C.orange} strokeWidth={2} dot={false} activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }} isAnimationActive={false} />
                <Line type="monotone" dataKey="offer" name="With transfer" stroke={C.blue} strokeWidth={2} dot={false} activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartFrame>

          <p className="text-xs leading-relaxed text-muted">
            Models a true 0% APR offer with no new purchases. Interest compounds
            monthly at APR ÷ 12. Deferred-interest promotions work differently and
            are not modeled. This is an estimate, not financial advice.
          </p>
        </>
      }
    />
  );
}
