"use client";

import { useMemo, useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Callout } from "@/components/Callout";
import { ChartFrame } from "@/components/ChartFrame";
import { ChartTooltip, endLabel } from "@/components/chart-parts";
import { Slider } from "@/components/Slider";
import { Stat, StatGrid } from "@/components/Stat";
import { Workbench } from "@/components/Workbench";
import { axisTick, C } from "@/lib/chart";
import { pct, usd, usdCents, usdCompact } from "@/lib/format";
import { simulateAuto, type AutoInputs } from "@/lib/calc/auto";

const DEFAULTS: AutoInputs = {
  price: 38000,
  salesTax: 7,
  downPayment: 5000,
  apr: 6.9,
  termMonths: 60,
  investReturn: 5,
};

export function AutoLoan() {
  const [v, setV] = useState<AutoInputs>(DEFAULTS);
  const set = (key: keyof AutoInputs) => (n: number) =>
    setV((s) => ({ ...s, [key]: n }));

  const r = useMemo(() => simulateAuto(v), [v]);

  const ticks = r.points.filter((p) => p.month % 12 === 0).map((p) => p.month);
  const financeWins = r.advantage > 50;
  const cashWins = r.advantage < -50;

  const verdict = financeWins ? (
    <Callout tone="good" title={`Financing comes out ${usd(r.advantage)} ahead, if you really earn ${pct(v.investReturn, 2)}.`}>
      Your cash earns more than the loan costs. The result depends on that return
      showing up every year of the loan.
    </Callout>
  ) : cashWins ? (
    <Callout tone="good" title={`Paying cash comes out ${usd(-r.advantage)} ahead.`}>
      The loan charges {pct(v.apr, 2)}, more than the {pct(v.investReturn, 2)} your
      cash would earn. Paying cash is a guaranteed {pct(v.apr, 2)} return.
    </Callout>
  ) : (
    <Callout tone="neutral" title="Roughly a wash.">
      The loan rate and your expected return are close, so choose on liquidity and
      risk rather than dollars.
    </Callout>
  );

  return (
    <Workbench
      controlsLabel="The car and the loan"
      controls={
        <>
          <Slider label="Vehicle price" value={v.price} min={10000} max={100000} step={500} onChange={set("price")} format={usd} />
          <Slider label="Sales tax" value={v.salesTax} min={0} max={10} step={0.25} onChange={set("salesTax")} format={(n) => pct(n, 2)} />
          <Slider label="Down payment" value={v.downPayment} min={0} max={50000} step={500} onChange={set("downPayment")} format={usd} />
          <Slider label="Loan APR" value={v.apr} min={0} max={15} step={0.1} onChange={set("apr")} format={(n) => pct(n)} />
          <Slider label="Loan term" value={v.termMonths} min={24} max={84} step={12} onChange={set("termMonths")} format={(n) => `${n} months`} />
          <Slider label="Return on cash you keep" value={v.investReturn} min={0} max={12} step={0.25} onChange={set("investReturn")} format={(n) => pct(n, 2)} hint="Use an after-tax figure you could actually earn." />
        </>
      }
      results={
        <>
          <StatGrid>
            <Stat
              label="Monthly payment"
              value={usdCents(r.payment)}
              note={`${usd(r.loanAmount)} borrowed`}
            />
            <Stat
              label="Loan interest"
              value={usd(r.totalInterest)}
              note={`Over ${v.termMonths} months`}
            />
            <Stat
              label="Investment growth"
              value={usd(r.totalEarnings)}
              note={`On ${usd(r.loanAmount)} kept invested`}
            />
            <Stat
              label={r.advantage >= 0 ? "Financing ahead by" : "Cash ahead by"}
              value={usd(Math.abs(r.advantage))}
              note={`Break-even return is ${pct(v.apr, 2)}`}
              emphasis
            />
          </StatGrid>

          {verdict}

          {r.runsOutMonth !== null && r.loanAmount > 0 ? (
            <Callout tone="warn" title={`Your invested cash would run out in month ${r.runsOutMonth}.`}>
              At this return the growth does not keep up with the payments, so the
              later payments would come from your regular income.
            </Callout>
          ) : null}

          <ChartFrame
            title="Interest you pay vs growth you earn"
            subtitle="Cumulative amounts. Financing wins only when the blue line finishes above the orange one."
            legend={[
              { label: "Growth on cash you kept", color: C.blue },
              { label: "Interest paid on the loan", color: C.orange },
            ]}
            height={300}
            table={{
              headers: ["Month", "Interest paid", "Investment growth", "Net"],
              rows: r.points
                .filter((p) => p.month % 6 === 0)
                .map((p) => [p.month, usd(p.interest), usd(p.earnings), usd(p.net)]),
            }}
          >
            <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 640, height: 300 }}>
              <LineChart data={r.points} margin={{ top: 12, right: 64, bottom: 4, left: 0 }}>
                <CartesianGrid vertical={false} stroke={C.grid} />
                <XAxis
                  dataKey="month"
                  type="number"
                  domain={[0, "dataMax"]}
                  ticks={ticks}
                  tick={axisTick}
                  tickLine={false}
                  axisLine={{ stroke: C.axis }}
                  tickFormatter={(n: number) => `${n / 12} yr`}
                />
                <YAxis domain={[0, "auto"]} tick={axisTick} tickLine={false} axisLine={false} width={52} tickFormatter={(n: number) => usdCompact(n)} />
                <Tooltip
                  cursor={{ stroke: C.axis }}
                  content={<ChartTooltip valueFormat={usd} labelFormat={(l) => `Month ${l}`} />}
                />
                <Line type="monotone" dataKey="interest" name="Interest paid" stroke={C.orange} strokeWidth={2} dot={false} activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }} label={endLabel(r.points.length - 1, usdCompact)} isAnimationActive={false} />
                <Line type="monotone" dataKey="earnings" name="Investment growth" stroke={C.blue} strokeWidth={2} dot={false} activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }} label={endLabel(r.points.length - 1, usdCompact)} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartFrame>

          <p className="text-xs leading-relaxed text-muted">
            Both paths buy the same car, so depreciation, insurance and upkeep
            cancel out and are left out. The financed path keeps the borrowed
            amount invested and pays the loan from it. Rebates for paying cash and
            promotional rates are not modeled. This is an estimate, not financial
            advice.
          </p>
        </>
      }
    />
  );
}
