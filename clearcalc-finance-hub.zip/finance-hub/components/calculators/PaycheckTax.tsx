"use client";

import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Callout } from "@/components/Callout";
import { ChartFrame } from "@/components/ChartFrame";
import { ChartTooltip, endLabel } from "@/components/chart-parts";
import { Segmented } from "@/components/Segmented";
import { Slider } from "@/components/Slider";
import { Stat, StatGrid } from "@/components/Stat";
import { Workbench } from "@/components/Workbench";
import { axisTick, C } from "@/lib/chart";
import { pct, usd, usdCompact } from "@/lib/format";
import {
  estimateTax,
  FILING_LABELS,
  STANDARD_DEDUCTION_2026,
  type FilingStatus,
  type TaxInputs,
} from "@/lib/calc/tax";

const DEFAULTS: TaxInputs = {
  status: "single",
  w2Income: 85000,
  sideRevenue: 24000,
  sideExpenses: 4000,
  stateRate: 4.5,
  retirementPct: 0,
};

const SEGMENT_COLORS = {
  keep: C.blue,
  federal: C.orange,
  se: C.aqua,
  state: C.yellow,
  expenses: C.magenta,
} as const;

export function PaycheckTax() {
  const [v, setV] = useState<TaxInputs>(DEFAULTS);
  const set = (key: keyof TaxInputs) => (n: number) =>
    setV((s) => ({ ...s, [key]: n }));

  const r = useMemo(() => estimateTax(v), [v]);

  const revenue = v.sideRevenue;
  const share = (n: number) => (revenue > 0 ? (n / revenue) * 100 : 0);
  const splitRow = Object.fromEntries([
    ["name", "Each dollar of revenue"],
    ...r.segments.map((s) => [s.key, share(s.value)]),
  ]);

  const needsEstimates = r.totalTax >= 1000;

  return (
    <Workbench
      controlsLabel="Your income"
      controls={
        <>
          <Segmented<FilingStatus>
            legend="Filing status"
            value={v.status}
            onChange={(s) => setV((p) => ({ ...p, status: s }))}
            options={(Object.keys(FILING_LABELS) as FilingStatus[]).map((k) => ({
              value: k,
              label: FILING_LABELS[k],
            }))}
          />
          <Slider label="Day-job wages" value={v.w2Income} min={0} max={400000} step={5000} onChange={set("w2Income")} format={usd} />
          <Slider label="Side-hustle revenue" value={v.sideRevenue} min={0} max={150000} step={1000} onChange={set("sideRevenue")} format={usd} />
          <Slider label="Business expenses" value={v.sideExpenses} min={0} max={60000} step={500} onChange={set("sideExpenses")} format={usd} hint="Software, supplies, mileage and other deductible costs." />
          <Slider label="State income tax rate" value={v.stateRate} min={0} max={12} step={0.25} onChange={set("stateRate")} format={(n) => pct(n, 2)} hint="A flat estimate. Set 0% if your state has no income tax." />
          <Slider label="Retirement contribution" value={v.retirementPct} min={0} max={20} onChange={set("retirementPct")} format={(n) => `${n}% of profit`} hint="Solo 401(k) or SEP-IRA, as a share of net profit." />
        </>
      }
      results={
        <>
          <StatGrid>
            <Stat
              label="You keep"
              value={usd(r.keep)}
              note={`${pct(r.netProfit > 0 ? (r.keep / r.netProfit) * 100 : 0, 0)} of ${usd(r.netProfit)} net profit`}
              emphasis
            />
            <Stat
              label="Tax on side income"
              value={usd(r.totalTax)}
              note={`${pct(r.effectiveRate * 100)} of net profit`}
              emphasis
            />
            <Stat
              label="Set aside per quarter"
              value={usd(r.quarterly)}
              note="Federal, self-employment and state"
            />
            <Stat
              label="Tax on your next $1"
              value={pct(r.marginalRate * 100, 0)}
              note="Of added side revenue"
            />
          </StatGrid>

          {r.netProfit <= 0 ? (
            <Callout tone="neutral" title="No net profit, so no self-employment tax.">
              Expenses cover your revenue. Raise revenue or lower expenses to see
              the tax picture.
            </Callout>
          ) : needsEstimates ? (
            <Callout tone="warn" title="Plan for quarterly estimated payments.">
              If you expect to owe $1,000 or more after withholding, the IRS expects
              payments during the year. You can also raise your day-job W-4
              withholding to cover it.
            </Callout>
          ) : (
            <Callout tone="good" title="Your added tax is under $1,000.">
              Estimated payments are usually not required below that level after
              withholding, but you still report the income.
            </Callout>
          )}

          {r.qbiMayBeLimited ? (
            <Callout tone="warn" title="At this income the 20% business deduction may be limited.">
              Above roughly $200,000 of taxable income ($400,000 for joint filers),
              the qualified business income deduction can shrink or disappear,
              especially for service businesses. This estimate still applies the
              full 20%, so your real bill may be higher.
            </Callout>
          ) : null}

          <ChartFrame
            title="Where each revenue dollar goes"
            subtitle="Share of side-hustle revenue, from expenses to what lands in your pocket."
            legend={r.segments.map((s) => ({
              label: s.label,
              color: SEGMENT_COLORS[s.key],
              kind: "swatch" as const,
            }))}
            height={120}
            table={{
              headers: ["Item", "Dollars", "Share of revenue"],
              rows: r.segments.map((s) => [s.label, usd(s.value), `${share(s.value).toFixed(1)}%`]),
            }}
          >
            <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 640, height: 120 }}>
              <BarChart data={[splitRow]} layout="vertical" margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
                <XAxis type="number" domain={[0, 100]} ticks={[0, 25, 50, 75, 100]} tick={axisTick} tickLine={false} axisLine={{ stroke: C.axis }} tickFormatter={(n: number) => `${n}%`} />
                <YAxis type="category" dataKey="name" hide />
                <Tooltip
                  cursor={false}
                  content={<ChartTooltip valueFormat={(n) => `${n.toFixed(1)}%`} />}
                />
                {r.segments.map((s, idx) => (
                  <Bar
                    key={s.key}
                    dataKey={s.key}
                    name={s.label}
                    stackId="split"
                    fill={SEGMENT_COLORS[s.key]}
                    stroke={C.surface}
                    strokeWidth={2}
                    barSize={32}
                    radius={idx === 0 ? [4, 0, 0, 4] : idx === r.segments.length - 1 ? [0, 4, 4, 0] : 0}
                    isAnimationActive={false}
                  />
                ))}
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>

          <ChartFrame
            title="What you keep as side revenue grows"
            subtitle="Holds your expense ratio steady. The marker shows today's revenue."
            legend={[
              { label: "You keep", color: C.blue },
              { label: "Tax on side income", color: C.orange },
            ]}
            height={280}
            table={{
              headers: ["Revenue", "You keep", "Tax"],
              rows: r.curve.map((p) => [usd(p.revenue), usd(p.keep), usd(p.tax)]),
            }}
          >
            <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 640, height: 280 }}>
              <LineChart data={r.curve} margin={{ top: 12, right: 64, bottom: 4, left: 0 }}>
                <CartesianGrid vertical={false} stroke={C.grid} />
                <XAxis dataKey="revenue" type="number" domain={[0, "dataMax"]} tick={axisTick} tickLine={false} axisLine={{ stroke: C.axis }} tickFormatter={(n: number) => usdCompact(n)} />
                <YAxis domain={[0, "auto"]} tick={axisTick} tickLine={false} axisLine={false} width={52} tickFormatter={(n: number) => usdCompact(n)} />
                <Tooltip cursor={{ stroke: C.axis }} content={<ChartTooltip valueFormat={usd} labelFormat={(l) => `Revenue ${usd(Number(l))}`} />} />
                <ReferenceLine x={Math.min(v.sideRevenue, r.curve[r.curve.length - 1].revenue)} stroke={C.inkSoft} strokeDasharray="4 4" />
                <Line type="monotone" dataKey="tax" name="Tax on side income" stroke={C.orange} strokeWidth={2} dot={false} activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }} label={endLabel(r.curve.length - 1, usdCompact)} isAnimationActive={false} />
                <Line type="monotone" dataKey="keep" name="You keep" stroke={C.blue} strokeWidth={2} dot={false} activeDot={{ r: 5, stroke: C.surface, strokeWidth: 2 }} label={endLabel(r.curve.length - 1, usdCompact)} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartFrame>

          <div className="rounded-xl border border-line">
            <h3 className="border-b border-line px-4 py-3 font-display text-lg font-semibold tracking-tight">
              How the estimate adds up
            </h3>
            <dl className="divide-y divide-line text-sm">
              {[
                ["Net profit (revenue minus expenses)", usd(r.netProfit)],
                ["Self-employment tax (15.3% of 92.35% of profit)", usd(r.seTax)],
                ["Deduction for half of self-employment tax", usd(r.halfSeDeduction)],
                ["Qualified business income deduction (20%)", usd(r.qbiDeduction)],
                [`Standard deduction, ${FILING_LABELS[v.status].toLowerCase()}`, usd(STANDARD_DEDUCTION_2026[v.status])],
                ["Retirement contribution", usd(r.retirement)],
                ["Federal income tax added", usd(r.fedTax)],
                ["State income tax added", usd(r.stateTax)],
              ].map(([k, val]) => (
                <div key={k} className="flex items-baseline justify-between gap-4 px-4 py-2">
                  <dt className="text-ink-soft">{k}</dt>
                  <dd className="font-semibold tabular-nums text-ink">{val}</dd>
                </div>
              ))}
            </dl>
          </div>

          <p className="text-xs leading-relaxed text-muted">
            Tax year 2026 federal brackets, standard deductions and the $184,500
            Social Security wage base. Simplified: ignores credits, itemized
            deductions, other income, the income limits on the QBI deduction and
            state-specific rules. This is an estimate, not tax advice.
          </p>
        </>
      }
    />
  );
}
