import type { CalcKey } from "@/lib/calculators";

/** Small line glyphs, one per calculator, drawn to hint at what the chart shows. */
export function CalcGlyph({ calc, size = 40 }: { calc: CalcKey; size?: number }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 40 40",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };

  switch (calc) {
    case "fire":
      return (
        <svg {...common}>
          <path d="M5 33h30" />
          <path d="M6 29c8 0 12-3 16-9s7-10 12-13" />
          <path d="M28 7h6v6" />
        </svg>
      );
    case "debt":
      return (
        <svg {...common}>
          <path d="M5 33h30" />
          <path d="M6 9h7v6h7v6h7v6h7" />
        </svg>
      );
    case "mortgage":
      return (
        <svg {...common}>
          <path d="M6 19 20 7l14 12" />
          <path d="M10 17v16h20V17" />
          <path d="M17 33v-9h6v9" />
        </svg>
      );
    case "tax":
      return (
        <svg {...common}>
          <path d="M5 33h30" />
          <path d="M10 33V18M20 33V9M30 33V23" />
          <path d="M8 14h4M18 5h4M28 19h4" />
        </svg>
      );
    case "auto":
      return (
        <svg {...common}>
          <path d="M5 26v-5l4-7h16l6 7h4v5" />
          <path d="M5 26h30" />
          <circle cx="13" cy="28" r="3.5" fill="#fff" />
          <circle cx="28" cy="28" r="3.5" fill="#fff" />
        </svg>
      );
  }
}
