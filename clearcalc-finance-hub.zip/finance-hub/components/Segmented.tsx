"use client";

interface Option<T extends string> {
  value: T;
  label: string;
}

interface SegmentedProps<T extends string> {
  legend: string;
  value: T;
  options: Option<T>[];
  onChange: (value: T) => void;
}

export function Segmented<T extends string>({
  legend,
  value,
  options,
  onChange,
}: SegmentedProps<T>) {
  return (
    <fieldset className="py-3">
      <legend className="text-sm font-medium text-ink">{legend}</legend>
      <div className="mt-2 grid grid-cols-1 gap-1.5 sm:grid-cols-3 xl:grid-cols-1">
        {options.map((o) => {
          const active = o.value === value;
          return (
            <button
              key={o.value}
              type="button"
              aria-pressed={active}
              onClick={() => onChange(o.value)}
              className={`rounded-lg border px-3 py-2 text-left text-sm font-medium transition-colors ${
                active
                  ? "border-brand bg-brand-wash text-brand-deep"
                  : "border-line bg-panel text-ink-soft hover:border-ink-soft hover:text-ink"
              }`}
            >
              {o.label}
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}
