"use client";

import { C } from "@/lib/chart";

interface TooltipItem {
  name?: string | number;
  value?: unknown;
  color?: string;
  payload?: { fill?: string } & Record<string, unknown>;
}

interface ChartTooltipProps {
  active?: boolean;
  payload?: ReadonlyArray<TooltipItem>;
  label?: unknown;
  labelFormat?: (label: unknown) => string;
  valueFormat: (value: number) => string;
}

/** Hover tooltip: one row per series, colored key beside ink text. */
export function ChartTooltip({
  active,
  payload,
  label,
  labelFormat,
  valueFormat,
}: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  const heading = labelFormat
    ? labelFormat(label)
    : label !== undefined
      ? String(label)
      : "";

  return (
    <div className="min-w-40 rounded-lg border border-line bg-panel px-3 py-2 text-sm shadow-lg">
      {heading ? (
        <p className="mb-1 font-semibold text-ink">{heading}</p>
      ) : null}
      <ul className="space-y-0.5">
        {payload.map((p, idx) => (
          <li key={`${p.name}-${idx}`} className="flex items-center gap-2">
            <span
              aria-hidden
              className="inline-block h-2.5 w-2.5 shrink-0 rounded-full"
              style={{ background: p.payload?.fill ?? p.color }}
            />
            <span className="text-ink-soft">{p.name}</span>
            <span className="ml-auto pl-3 font-semibold tabular-nums text-ink">
              {valueFormat(Number(p.value))}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

interface LabelProps {
  x?: number | string;
  y?: number | string;
  /** Recharts passes numbers, strings, arrays or null here, so accept anything and coerce. */
  value?: unknown;
  index?: number;
}

/** Value label on the final point of a line or area (text stays in ink, never the series color). */
export function endLabel(lastIndex: number, format: (v: number) => string) {
  return function EndLabel(props: LabelProps) {
    if (props.index !== lastIndex) return null;
    const raw = Array.isArray(props.value)
      ? props.value[props.value.length - 1]
      : props.value;
    return (
      <text
        x={Number(props.x) + 8}
        y={Number(props.y)}
        dy={4}
        fill={C.ink}
        fontSize={12}
        fontWeight={600}
      >
        {format(Number(raw))}
      </text>
    );
  };
}
