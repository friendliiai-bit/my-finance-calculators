import type { ReactNode } from "react";

export interface LegendItem {
  label: string;
  color: string;
  /** "line" for line and area series, "swatch" for filled bars */
  kind?: "line" | "swatch";
}

interface TableData {
  headers: string[];
  rows: (string | number)[][];
}

export function ChartFrame({
  title,
  subtitle,
  legend,
  height = 300,
  table,
  children,
}: {
  title: string;
  subtitle?: string;
  legend?: LegendItem[];
  height?: number;
  table?: TableData;
  children: ReactNode;
}) {
  return (
    <figure className="rounded-xl border border-line bg-panel p-4 sm:p-5">
      <figcaption>
        <h3 className="font-display text-lg font-semibold leading-tight tracking-tight">
          {title}
        </h3>
        {subtitle ? (
          <p className="mt-0.5 text-sm text-ink-soft">{subtitle}</p>
        ) : null}
        {legend && legend.length > 1 ? (
          <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 text-sm text-ink-soft">
            {legend.map((l) => (
              <li key={l.label} className="flex items-center gap-2">
                <span
                  aria-hidden
                  className={`inline-block rounded-full ${
                    l.kind === "swatch" ? "h-3 w-3 rounded-sm" : "w-5"
                  }`}
                  style={{
                    background: l.color,
                    height: l.kind === "swatch" ? 12 : 3,
                  }}
                />
                {l.label}
              </li>
            ))}
          </ul>
        ) : null}
      </figcaption>

      <div className="mt-3 w-full" style={{ height }}>
        {children}
      </div>

      {table ? (
        <details className="mt-3 text-sm">
          <summary className="cursor-pointer font-medium text-brand-deep">
            View the data as a table
          </summary>
          <div className="mt-2 max-h-64 overflow-auto rounded-lg border border-line">
            <table className="w-full border-collapse text-left tabular-nums">
              <thead className="sticky top-0 bg-paper">
                <tr>
                  {table.headers.map((h) => (
                    <th
                      key={h}
                      scope="col"
                      className="px-3 py-2 font-semibold text-ink"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {table.rows.map((r, i) => (
                  <tr key={i} className="border-t border-line">
                    {r.map((cell, j) => (
                      <td key={j} className="px-3 py-1.5 text-ink-soft">
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </details>
      ) : null}
    </figure>
  );
}
