import type { ReactNode } from "react";

type Tone = "good" | "warn" | "neutral";

const TONES: Record<Tone, string> = {
  good: "border-[#b5dcb5] bg-good-wash text-good",
  warn: "border-[#efd2a0] bg-warn-wash text-warn",
  neutral: "border-line bg-brand-wash text-brand-deep",
};

function Icon({ tone }: { tone: Tone }) {
  const common = {
    width: 20,
    height: 20,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
    className: "mt-0.5 shrink-0",
  };
  if (tone === "good")
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="9" />
        <path d="m8 12.5 2.8 2.8L16 9.5" />
      </svg>
    );
  if (tone === "warn")
    return (
      <svg {...common}>
        <path d="M12 3.5 2.8 19.5h18.4L12 3.5Z" />
        <path d="M12 10v4.5M12 17.2v.1" />
      </svg>
    );
  return (
    <svg {...common}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 11v5M12 7.8v.1" />
    </svg>
  );
}

export function Callout({
  tone = "neutral",
  title,
  children,
}: {
  tone?: Tone;
  title: string;
  children?: ReactNode;
}) {
  return (
    <div
      role="status"
      className={`flex gap-3 rounded-xl border p-4 ${TONES[tone]}`}
    >
      <Icon tone={tone} />
      <div className="min-w-0">
        <p className="font-semibold leading-snug">{title}</p>
        {children ? (
          <div className="mt-1 text-sm leading-relaxed text-ink-soft">
            {children}
          </div>
        ) : null}
      </div>
    </div>
  );
}
