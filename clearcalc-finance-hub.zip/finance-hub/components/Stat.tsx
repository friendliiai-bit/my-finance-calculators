import type { ReactNode } from "react";

export function StatGrid({
  children,
  cols = 4,
}: {
  children: ReactNode;
  cols?: 2 | 3 | 4;
}) {
  // Four tiles sit two by two. The results column never grows past roughly 540px, which is
  // too narrow for four large figures in a row (they clip), so there is no wider breakpoint.
  const colClass =
    cols === 2
      ? "sm:grid-cols-2"
      : cols === 3
        ? "sm:grid-cols-3"
        : "sm:grid-cols-2";
  return (
    <dl
      className={`grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-line bg-line ${colClass}`}
    >
      {children}
    </dl>
  );
}

export function Stat({
  label,
  value,
  note,
  emphasis = false,
}: {
  label: string;
  value: string;
  note?: string;
  emphasis?: boolean;
}) {
  return (
    <div className="bg-panel p-4">
      <dt className="text-sm text-ink-soft">{label}</dt>
      <dd
        className={`mt-1 font-semibold leading-tight tracking-tight text-ink ${
          emphasis ? "text-[2rem]" : "text-[1.625rem]"
        }`}
      >
        {value}
      </dd>
      {note ? <p className="mt-1 text-xs text-muted">{note}</p> : null}
    </div>
  );
}
