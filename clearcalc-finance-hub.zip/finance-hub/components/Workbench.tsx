import type { ReactNode } from "react";

/** The interactive widget frame: flat controls on the left, results on the right. */
export function Workbench({
  controls,
  results,
  controlsLabel = "Your numbers",
}: {
  controls: ReactNode;
  results: ReactNode;
  controlsLabel?: string;
}) {
  return (
    <div
      id="calculator"
      className="overflow-hidden rounded-2xl border border-line bg-panel shadow-[0_1px_2px_rgb(20_35_59/0.06)]"
    >
      <div className="grid xl:grid-cols-[19rem_minmax(0,1fr)]">
        <section
          aria-label={controlsLabel}
          className="divide-y divide-line border-b border-line bg-paper/70 px-5 py-3 xl:border-b-0 xl:border-r"
        >
          <h2 className="py-3 font-display text-lg font-semibold tracking-tight">
            {controlsLabel}
          </h2>
          <div className="divide-y divide-line">{controls}</div>
        </section>
        <section aria-live="polite" className="space-y-5 p-5">
          {results}
        </section>
      </div>
    </div>
  );
}
