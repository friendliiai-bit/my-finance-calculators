import Link from "next/link";
import { CALCULATOR_LIST } from "@/lib/calculators";
import { SITE } from "@/lib/site";

export function Footer() {
  return (
    <footer className="mt-8 border-t border-line bg-panel">
      <div className="mx-auto grid max-w-[1200px] gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr]">
        <div className="max-w-md">
          <p className="font-display text-lg font-bold tracking-tight">{SITE.name}</p>
          <p className="mt-2 text-sm leading-relaxed text-ink-soft">
            {SITE.tagline}. Every calculator runs in your browser, and nothing you
            type is sent to a server.
          </p>
          <p className="mt-4 text-xs leading-relaxed text-muted">
            Results are estimates for education, not financial, tax or legal
            advice. Some links are affiliate links: we may earn a commission if
            you sign up, at no cost to you, and it does not change the math. Talk
            to a qualified professional before making major decisions.
          </p>
        </div>
        <nav aria-label="Footer">
          <p className="text-sm font-semibold">Calculators</p>
          <ul className="mt-3 space-y-2 text-sm">
            {CALCULATOR_LIST.map((c) => (
              <li key={c.key}>
                <Link href={c.href} className="text-ink-soft hover:text-ink hover:underline">
                  {c.title}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="border-t border-line">
        <p className="mx-auto max-w-[1200px] px-4 py-4 text-xs text-muted sm:px-6">
          © {new Date().getFullYear()} {SITE.name}
        </p>
      </div>
    </footer>
  );
}
