# ClearCalc: financial calculator hub

Five interactive calculators built with Next.js (App Router), Tailwind CSS v4 and Recharts.
Every page is statically prerendered. All calculations run in the browser, so nothing a visitor
types leaves their device.

| Route | Calculator |
| --- | --- |
| `/` | Home: live compounding teaser and links to all five tools |
| `/fire-calc` | FIRE & Compound Growth Calculator |
| `/debt-payoff` | 0% APR Debt Payoff Simulator |
| `/mortgage-payoff` | Mortgage Extra Payment Calculator |
| `/paycheck-tax` | Side-Hustle Net Tax Estimator (2026 US federal figures) |
| `/auto-loan` | Auto Loan vs Cash Calculator |

Each calculator page has the same anatomy: header navigation, an interactive widget (sliders,
stat tiles, Recharts charts, a data table behind each chart), a sticky sidebar of affiliate
cards, then an 800+ word guide with five FAQs and `FAQPage` / `WebApplication` JSON-LD.

## Run it

```bash
npm install
npm run dev          # http://localhost:3000
npm run build && npm start
```

Checks:

```bash
npm run typecheck    # tsc --noEmit
npm run test:math    # formulas checked against hand-computed values
npm run count:words  # fails if any article is under 800 words (FAQs are extra)
```

## Where things live

```
app/                     routes, metadata, sitemap.ts, robots.ts
components/calculators/  the five client-side widgets
components/              shell: Header, Footer, Slider, Stat, ChartFrame, AffiliateSidebar, SeoContent
lib/calc/                pure TypeScript math, one file per calculator (no React)
lib/affiliates.ts        sidebar cards per calculator
lib/calculators.ts       titles, taglines, meta descriptions, nav labels
content/                 the written guide and FAQs for each page
scripts/                 check-math.ts and count-words.ts
```

## Before you launch

1. **Affiliate links.** Cards link to each partner's public homepage by default. Set the
   `AFFILIATE_*` variables listed in `.env.example` to your tracked URLs, and delete any partner
   whose program you have not joined. Edit the card copy to match each program's terms. Links
   carry `rel="sponsored"` and the sidebar and footer include a disclosure.
2. **Site URL.** Set `NEXT_PUBLIC_SITE_URL` so canonical URLs, the sitemap and JSON-LD are right.
   Site name and tagline are in `lib/site.ts`.
3. **Tax tables.** `lib/calc/tax.ts` holds the 2026 brackets, standard deductions and the $184,500
   Social Security wage base (IRS Rev. Proc. 2025-32 and the SSA announcement). Update them each
   year, and the year mentioned in `lib/calculators.ts` and `content/tax.ts`.
4. **Legal pages.** The footer carries an estimates-not-advice disclaimer. Add a privacy policy and
   terms page appropriate to where you operate.

## Modeling notes and limits

- **FIRE:** monthly steps at the real return, `(1 + nominal) / (1 + inflation) - 1`. Contributions
  are constant in today's dollars. Taxes, Social Security and changing spending are not modeled.
- **0% APR:** true 0% APR only. The transfer fee is added to the starting balance, and interest after
  the promotion compounds monthly. Deferred-interest offers (retroactive interest) are not modeled.
- **Mortgage:** fixed rate, standard amortization, extras applied to principal. Monthly extras plus an
  optional lump sum in every 12th month. Principal and interest only.
- **Side-hustle tax:** measures the extra tax caused by the side income on top of wages: 15.3% self-
  employment tax on 92.35% of profit (Social Security portion capped by the wage base net of wages),
  the extra 0.9% Medicare tax, half-SE deduction, standard deduction, optional retirement
  contribution, 20% QBI deduction and a flat state rate. The QBI income limits are not applied; the
  widget shows a warning at high incomes instead.
- **Auto loan vs cash:** the financed path keeps the borrowed amount invested and pays the loan from
  it, so the break-even return equals the loan APR. Rebates and trade-ins are not modeled.

All results are estimates for education, not financial, tax or legal advice.
