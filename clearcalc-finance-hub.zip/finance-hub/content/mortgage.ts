import type { SeoCopy } from "@/components/SeoContent";

export const mortgageCopy: SeoCopy = {
  heading: "How extra mortgage payments save interest",
  intro: [
    "Every mortgage payment splits into interest and principal. Early in the loan most of it goes to interest, so the balance barely moves. Extra payments go straight to principal, which means you owe less next month and pay interest on a smaller number from then on. Over the years that effect can remove tens of thousands of dollars of interest and several years from the loan.",
    "Enter your current balance, rate and remaining term, then add an extra monthly amount or a yearly lump sum such as a tax refund or bonus. The first chart compares the balance on your current schedule with the faster one, and the results show your payoff time, interest saved and time saved.",
  ],
  sections: [
    {
      heading: "Why early extra payments work best",
      body: [
        "Interest is charged on the outstanding balance each month. A dollar of principal removed in year two avoids interest for the rest of the loan, while a dollar removed in year twenty-five avoids very little. That is why the same extra payment saves far more when the loan is young.",
        "On a $320,000 balance at 6.5% with 27 years left, the regular payment is about $2,098 a month and the loan costs roughly $359,700 in interest. Adding $300 a month ends the loan about seven years sooner and saves around $110,000 of that interest.",
      ],
    },
    {
      heading: "Monthly extra payments versus a yearly lump sum",
      body: [
        "Regular extra payments are easy to automate and start working immediately. A lump sum, such as a tax refund or bonus, suits uneven income and still lands directly on principal. The tool lets you combine both.",
        "Timing matters less than the habit. Biweekly plans work the same way, because 26 half-payments equal 13 full payments a year, which is one extra payment you barely notice.",
      ],
    },
    {
      heading: "A guaranteed return versus investing the difference",
      body: [
        "Every extra dollar you send to your mortgage earns your loan rate, with no market risk. At 6.5% that is a return few safe investments can match. If your rate is 3%, the case is weaker, since a diversified portfolio has historically earned more over long periods, though with real ups and downs.",
        "There is no universal answer. Consider your rate, your comfort with risk, whether you have captured any employer retirement match, and whether you hold high-interest debt. Paying off a 24% credit card beats prepaying a 6% mortgage every time.",
      ],
    },
    {
      heading: "Check the fine print before paying extra",
      body: [
        "Most modern mortgages allow extra payments without penalty, but some include prepayment charges in the early years, so read your note. Tell your servicer to apply the extra amount to principal, because otherwise it may be treated as an early payment of next month's installment, which saves nothing.",
        "Keep an emergency fund and your other goals in view, because home equity is hard to reach quickly. Remember too that this calculator covers principal and interest only. Property taxes, insurance and any mortgage insurance continue until the loan ends.",
      ],
    },
    {
      heading: "Refinance, recast or prepay: choosing the right tool",
      body: [
        "Extra payments are one of three ways to change a mortgage. A refinance replaces the loan with a new one at a new rate and term, which can lower the rate but adds closing costs and often restarts the clock. A recast keeps your rate and term and recalculates a lower payment after you pay down a lump sum. Prepaying leaves the payment alone and shortens the loan. Each fits a different goal: a lower rate calls for a refinance, a lower payment calls for a recast, and an earlier finish line calls for prepaying.",
        "If today's rates are well below yours, price a refinance first, then use this calculator on the new loan to see how extra payments would work with it. If rates are above yours, refinancing would trade a cheap loan for an expensive one, so prepaying the mortgage you already have becomes more attractive. Enter the balance and rate of whichever loan you are considering and compare the interest saved on each.",
        "Closing costs are the hidden variable in any refinance, so divide them by the monthly savings to find how many months it takes to break even.",
      ],
    },
    {
      heading: "Other benefits of paying down principal",
      body: [
        "Faster principal reduction builds equity sooner, which can help you reach 80% loan-to-value and request removal of private mortgage insurance on a conventional loan. It also leaves you a lower balance if you decide to refinance or sell.",
        "On the other side, you give up the mortgage interest deduction on the interest you no longer pay, though many households no longer itemize, so the deduction often does not apply.",
      ],
    },
    {
      heading: "How to use the calculator",
      body: [
        "Enter the balance from your latest statement, your interest rate and the years left on the loan. Start with a monthly amount you can sustain without strain, then watch the payoff time and interest saved update. Add a yearly lump sum to see how a bonus changes the picture.",
        "The second chart compares lifetime interest on both paths so you can see the size of the prize in dollars.",
      ],
    },
  ],
  faqs: [
    {
      question: "Should I make extra mortgage payments or invest?",
      answer:
        "It depends on your rate and risk tolerance. Prepaying earns a guaranteed return equal to your mortgage rate, while investing offers higher expected returns with uncertainty. Many people split the difference after funding retirement accounts and an emergency fund.",
    },
    {
      question: "Do extra payments lower my monthly payment?",
      answer:
        "Not on most loans. Your required payment stays the same and the loan simply ends sooner. To lower the payment you would need to recast or refinance, and both can carry fees.",
    },
    {
      question: "What is mortgage recasting?",
      answer:
        "Recasting means paying a large lump sum and asking your lender to recalculate the payment on the smaller balance over the same remaining term. Some lenders charge a modest fee, and not every loan type qualifies, so ask your servicer.",
    },
    {
      question: "Is a biweekly payment plan worth it?",
      answer:
        "Biweekly payments produce one extra monthly payment per year, which shortens the loan. You can get the same effect by adding one twelfth of a payment to each monthly payment, usually without paying a third party's setup fee.",
    },
    {
      question: "Does this work for adjustable-rate mortgages?",
      answer:
        "Only roughly, because the calculator assumes your rate stays fixed. For an adjustable loan, rerun it each time the rate resets, using your current balance and remaining term.",
    },
  ],
};
