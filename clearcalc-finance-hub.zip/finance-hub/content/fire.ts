import type { SeoCopy } from "@/components/SeoContent";

export const fireCopy: SeoCopy = {
  heading: "How financial independence math works",
  intro: [
    "Financial independence means your investments can pay your living costs without a paycheck. This calculator reduces that idea to three numbers: the portfolio you need, the years it takes at your current pace, and the age you would reach it. Every figure is in today's dollars, so $1.2 million means $1.2 million of buying power rather than a bigger number inflated by decades of rising prices.",
    "Move the sliders to test different futures. The chart sets what you have contributed against what the market has added, with a line marking the point where work becomes optional. Small changes to savings or spending often move the finish line by years, which is the real lesson of the exercise.",
  ],
  sections: [
    {
      heading: "The FI number and the 4% rule",
      body: [
        "Your FI number is your yearly spending divided by your withdrawal rate. At a 4% rate that is 25 times annual expenses, so $48,000 of yearly spending needs a $1.2 million portfolio. The rule comes from the Trinity Study and related research, which tested how long portfolios of stocks and bonds survived steady inflation-adjusted withdrawals over 30-year retirements in US history.",
        "Early retirees plan for 40 or 50 years, so many choose a lower rate such as 3.5%, which raises the target to about 28.6 times spending. Notice how sensitive the number is: cutting expenses lowers the target and raises your savings at the same time.",
      ],
    },
    {
      heading: "How compound growth carries the second half of the journey",
      body: [
        "In the early years most of your balance is money you put in. Later, growth does the heavy lifting. At a 4.4% real return a portfolio of $500,000 adds about $22,000 a year before you contribute anything, which is more than many people save annually. That is why the two areas on the chart separate slowly and then fan apart.",
        "It also explains why starting early matters more than the exact amount. A dollar invested at 30 has decades to multiply, while a dollar invested at 50 has far fewer. If your balance never reaches the FI line, the fix is almost always more contributions or lower spending, not a hunt for a higher return.",
      ],
    },
    {
      heading: "Why the calculator uses real returns",
      body: [
        "A nominal return of 7% sounds generous until 2.5% inflation takes its share. The tool converts your two assumptions into a single real return, about 4.4% in the default setup, and grows your balance at that rate while keeping contributions constant in today's money.",
        "This avoids a common trap in retirement planning, where a large future dollar total looks impressive but buys much less than it seems. Be cautious with optimistic returns: a one-point change in the assumption shifts the result more than most people expect.",
      ],
    },
    {
      heading: "Choosing a withdrawal rate",
      body: [
        "A higher withdrawal rate reaches FI sooner but leaves less room for bad luck. Sequence-of-returns risk, meaning a market drop in the first few years of retirement, is the main danger, because you sell shares while prices are low and cannot reclaim them later.",
        "People manage that risk with flexible spending, a cash buffer of one or two years of expenses, part-time income in the early years, or a more conservative rate. Try 3.5%, 4% and 4.5% on the slider and watch the target and the timeline change together.",
      ],
    },
    {
      heading: "Coast FIRE and barista FIRE: two shortcuts",
      body: [
        "Not everyone wants to save until the full number is in hand. Coast FIRE describes the point where your current balance, left alone to grow, would reach your FI number by a traditional retirement age such as 65, so you only need to earn enough to cover today's expenses. Barista FIRE describes leaving full-time work once your portfolio can bridge most of the gap, then covering the rest with part-time income and, often, employer health benefits.",
        "You can explore both with this tool. Set the monthly contribution slider to zero and see whether the balance still crosses the FI line before your target age, which is a rough Coast FIRE test. For a barista plan, reduce the annual spending slider by the amount your part-time job would cover and watch how much smaller the required portfolio becomes. Either way, the target moves with your spending, so revisit these figures whenever your costs change.",
      ],
    },
    {
      heading: "What this estimate leaves out",
      body: [
        "No model captures everything. This one ignores taxes on withdrawals, which depend heavily on whether your money sits in tax-deferred, Roth or taxable accounts. It also leaves out health insurance before Medicare, Social Security benefits later, one-time costs, and the way spending tends to change across retirement.",
        "Treat the result as a planning compass, not a forecast. Revisit it once a year with real balances, and consider talking with a fee-only planner before you leave a job.",
      ],
    },
    {
      heading: "Practical ways to reach FI sooner",
      body: [
        "Three levers matter, and they are not equal. Spending is the strongest, because it lowers the target and frees money to save. Savings rate comes next, since every extra dollar compounds. Returns are the weakest lever because you cannot control them, though keeping investment fees low protects what you earn.",
        "Use the contribution slider to test an extra $500 a month. The note under the results tells you how many years it saves.",
      ],
    },
  ],
  faqs: [
    {
      question: "What does FIRE stand for?",
      answer:
        "FIRE stands for Financial Independence, Retire Early. Financial independence is the goal, and whether you actually stop working is a personal choice. Many people pursue it for flexibility, such as changing careers or working part-time.",
    },
    {
      question: "Is the 4% rule safe?",
      answer:
        "It has held up in most historical US scenarios over 30 years, but it is not a guarantee, and longer retirements are less certain. A lower rate, flexible spending and a cash buffer all improve the odds.",
    },
    {
      question: "What investment return should I assume?",
      answer:
        "A common planning range is 5% to 7% nominal for a diversified, stock-heavy portfolio, and the calculator subtracts inflation for you. Choose a number you would be comfortable missing, then test 4%, 6% and 8% to see how much the plan depends on it.",
    },
    {
      question: "What is the difference between lean FIRE and fat FIRE?",
      answer:
        "Lean FIRE means a small, frugal budget, often under $40,000 a year. Fat FIRE means a larger budget with room for travel and luxuries. Use the spending slider to see how the target scales with each lifestyle.",
    },
    {
      question: "Does the calculator include Social Security or taxes?",
      answer:
        "No. It treats withdrawals as spendable income and leaves out Social Security. If benefits or taxes matter to your plan, adjust annual spending to reflect the net amount you need after those items.",
    },
  ],
};
