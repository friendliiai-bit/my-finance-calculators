import type { SeoCopy } from "@/components/SeoContent";

export const taxCopy: SeoCopy = {
  heading: "How side-hustle income is taxed in 2026",
  intro: [
    "When you earn money outside a job, nobody withholds tax for you, and the bill arrives all at once. Side income is taxed three ways: self-employment tax for Social Security and Medicare, federal income tax at your top bracket, and state income tax where you live. This estimator stacks your side profit on top of your day-job wages and measures only the extra tax the side hustle causes.",
    "Enter your wages, revenue and expenses, pick a filing status and adjust the sliders. You will see what you keep, the tax by type, how much to set aside each quarter, and how your take-home grows as revenue rises. It uses 2026 federal figures.",
  ],
  sections: [
    {
      heading: "Self-employment tax: the part that surprises people",
      body: [
        "Employees split Social Security and Medicare tax with their employer. When you work for yourself, you pay both halves, 15.3% in total, on 92.35% of your net profit. The 12.4% Social Security portion applies only up to the annual wage base, which is $184,500 for 2026 and is shared with your wages, so higher earners may pay only the 2.9% Medicare portion on side income.",
        "In the default example, $20,000 of profit creates about $2,800 of self-employment tax before any income tax. You may deduct half of it when figuring income tax.",
      ],
    },
    {
      heading: "Federal income tax and the 2026 brackets",
      body: [
        "Side profit is added to your wages and taxed at your marginal rate. For 2026 the standard deduction is $16,100 for single filers, $32,200 for married couples filing jointly and $24,150 for heads of household, and the seven rates run from 10% to 37%.",
        "A single filer with $85,000 of wages sits in the 22% bracket, so extra profit is taxed there. Because brackets are marginal, only the slice above each threshold is taxed at the higher rate, not your whole income.",
      ],
    },
    {
      heading: "The qualified business income deduction",
      body: [
        "Many sole proprietors can deduct up to 20% of qualified business income, which lowers the effective federal rate on side profit. In the default example it removes about $3,700 from taxable income.",
        "The deduction has income limits and special rules for certain service businesses at higher incomes, which this simplified calculator does not apply. Treat the figure as an estimate, and confirm it with a tax professional if your total income is high.",
      ],
    },
    {
      heading: "Business expenses and retirement contributions",
      body: [
        "Ordinary and necessary expenses reduce your profit before any of these taxes are calculated, so tracking them pays twice: less self-employment tax and less income tax. Common examples include software, supplies, a home-office portion, advertising and business mileage.",
        "Contributions to a solo 401(k) or SEP-IRA reduce income tax further, though not self-employment tax. Use the retirement slider to see how a contribution changes what you keep.",
      ],
    },
    {
      heading: "Quarterly estimated payments",
      body: [
        "The IRS expects tax to be paid as income is earned. If you expect to owe $1,000 or more after withholding and credits, you generally make estimated payments four times a year, or raise the withholding on your day job's W-4 to cover the gap. The calculator divides your side-hustle tax by four as a starting point.",
        "Missing payments can lead to an underpayment penalty, so move a percentage of every payment you receive into a separate savings account as soon as it arrives.",
      ],
    },
    {
      heading: "A worked example",
      body: [
        "Take a single filer with $85,000 of wages who earns $24,000 from freelancing and spends $4,000 on business costs, in a state with a 4.5% income tax. Net profit is $20,000. The side hustle adds about $2,826 of self-employment tax, $3,271 of federal income tax and $836 of state tax, for a total of roughly $6,934.",
        "That leaves about $13,066 in your pocket, an effective rate near 35% of profit, and a quarterly set-aside of about $1,733. Change any slider to see how the picture moves.",
      ],
    },
    {
      heading: "Higher incomes: the extra Medicare tax and QBI limits",
      body: [
        "High earners face two additional rules. An extra 0.9% Medicare tax applies to earned income above $200,000 for single filers and $250,000 for married couples filing jointly, and the calculator includes it when your wages plus self-employment earnings cross that line. The qualified business income deduction is also limited once taxable income passes a threshold that is adjusted each year, and it can shrink or disappear for service businesses such as consulting, health or law.",
        "The estimator applies the full 20% deduction at every income level and shows a warning when your income is high enough that it may not hold, so treat the result as optimistic in that range. If you are near those limits, a tax professional can model your situation exactly, and the cost of that advice is often smaller than the cost of a wrong estimate.",
      ],
    },
    {
      heading: "What the estimate leaves out",
      body: [
        "This tool is a simplified federal estimate with a flat state rate. It ignores credits, itemized deductions, investment income, local taxes and state-specific rules. If you operate as an S corporation, live in a state with unusual rules, or have complicated income, consult a tax professional.",
      ],
    },
  ],
  faqs: [
    {
      question: "Do I owe tax on side-hustle income under $400?",
      answer:
        "You do not owe self-employment tax on net earnings below $400, but the income is still taxable and should be reported. Platforms may send you a tax form even for small amounts.",
    },
    {
      question: "What percent should I set aside for taxes?",
      answer:
        "With a day job in the 22% bracket, the default example lands near 35% of net profit including state tax. Many freelancers set aside 25% to 35%, then adjust after a full year. Use the effective rate in the results as a starting point.",
    },
    {
      question: "Can I deduct my home office or car?",
      answer:
        "Possibly, if the space or vehicle is used regularly and exclusively for business and you keep records. Mileage is typically tracked with a log. The rules are specific, so keep receipts and ask a tax professional.",
    },
    {
      question: "Is self-employment tax deductible?",
      answer:
        "Half of it is. The calculator subtracts that half when it figures your income tax, which lowers the federal bill.",
    },
    {
      question: "When are estimated taxes due?",
      answer:
        "Estimated payments are generally due in April, June, September and January. If a due date falls on a weekend or holiday, it moves to the next business day. Confirm the exact dates on the IRS website each year.",
    },
  ],
};
