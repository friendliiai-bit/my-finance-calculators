import type { SeoCopy } from "@/components/SeoContent";

export const debtCopy: SeoCopy = {
  heading: "How a 0% APR balance transfer works",
  intro: [
    "A 0% APR balance transfer moves your card debt to a new card that charges no interest for a promotional period, usually 12 to 21 months. In exchange you pay a one-time transfer fee, commonly 3% to 5% of the amount moved. Whether the trade is worth it comes down to one question: can you clear the balance before the promotion ends? This simulator answers it with your own numbers.",
    "Enter your balance, the length of the offer, the fee and what you can pay each month. The chart compares two paths: staying on your current card and moving to the 0% offer. The results show the balance left when the promotion ends, the time to become debt-free on each path, and the net saving after fees.",
  ],
  sections: [
    {
      heading: "What the transfer fee really costs",
      body: [
        "The fee is added to your balance on day one. A 3% fee on $8,000 is $240, so you start the promotion owing $8,240. That fee is interest in disguise, and it is the number to beat.",
        "If your current card charges about 23% APR, you would pay roughly $150 a month in interest on the same balance, so the fee pays for itself in about two months. A 5% fee takes slightly longer but usually still wins. The exception is a small balance you could clear within a month or two, where the fee may exceed the interest you would have paid.",
      ],
    },
    {
      heading: "The payment needed to finish inside the promotion",
      body: [
        "Divide the starting balance, including the fee, by the number of promotional months. On $8,240 over 15 months that is about $549 a month. If your payment is lower, a balance remains when the promotion ends and interest begins on whatever is left, usually at a rate similar to your old card.",
        "The simulator shows this directly in the note under the results, along with a rough estimate of the interest you would then owe. Treat the required payment as a fixed line in your budget, and set up autopay for at least the minimum so one late payment does not cancel the offer.",
      ],
    },
    {
      heading: "0% APR versus deferred interest",
      body: [
        "Real 0% APR offers never charge interest during the promotion. Deferred-interest offers, common with store cards and some medical or retail financing, look similar but behave differently: if any balance remains at the end, interest is charged retroactively from the original purchase date.",
        "Read the terms before you apply. This simulator models true 0% APR only, so do not use it for a deferred-interest deal unless you are certain you will pay the full amount in time.",
      ],
    },
    {
      heading: "Protecting your credit while you do this",
      body: [
        "Applying for a new card triggers a hard inquiry, which can lower your score by a few points for a short time. A new account also reduces the average age of your credit history. Those effects usually fade, and paying down debt typically helps your score through lower utilization.",
        "Avoid running up the old card again after the transfer, because that is the most common reason people end up worse off. Keep the old account open if it has no annual fee, but take it out of your wallet.",
      ],
    },
    {
      heading: "Balance transfer, personal loan or paying down your current card",
      body: [
        "A 0% transfer is one of three common routes. Paying down your current card needs no application and no fee, but interest keeps running at the card's regular rate. A fixed-rate personal loan replaces the card balance with a predictable payment and a set end date, though the rate will usually be above 0% and some lenders charge an origination fee. A transfer has the lowest interest cost when you qualify, and its cost is the fee plus whatever remains when the offer expires.",
        "To compare them, run the transfer through the simulator, then set the post-promotion APR to the rate you would actually face and the current-card APR to what you pay today. If the net saving after the fee is small or negative, the transfer is not worth the hard inquiry and the effort. If it is large, the next question is whether your budget can deliver the payment shown in the results, because a plan you cannot fund is worse than no plan.",
      ],
    },
    {
      heading: "When a transfer is not the right tool",
      body: [
        "A transfer helps when you have a plan to repay on a fixed schedule. It helps less if your spending still exceeds your income, because the underlying cause remains. In that case, build a budget first, or look at a fixed-rate personal loan or a nonprofit credit counseling plan.",
        "Also check that you qualify. The best offers usually require good credit, and the limit on the new card may be lower than your balance.",
      ],
    },
    {
      heading: "How to use the simulator",
      body: [
        "Start with your real numbers, then adjust the monthly payment slider until the balance at the end of the promotion reaches zero. Add a small safety margin. Then raise the post-promotion APR to see how costly it is to miss the deadline.",
      ],
    },
  ],
  faqs: [
    {
      question: "How long do 0% APR balance transfer offers last?",
      answer:
        "Most run between 12 and 21 months, with longer terms usually reserved for strong credit. The clock typically starts when the account opens, and transfers often must be made within the first few months to qualify for the promotional rate.",
    },
    {
      question: "Is a balance transfer fee negotiable?",
      answer:
        "Rarely. Fees are set by the card issuer, and the lowest advertised fee is usually the best you will get. Compare offers by total cost, which combines the fee and the length of the interest-free period, rather than by either number alone.",
    },
    {
      question: "What happens if I miss a payment?",
      answer:
        "Many issuers can end the promotional rate after a late payment, and a penalty rate may apply. Set up autopay for at least the minimum and add a calendar reminder for the full payment amount.",
    },
    {
      question: "Can I transfer a balance between cards from the same bank?",
      answer:
        "Usually not. Issuers typically do not allow transfers between their own cards, so you will need a card from a different bank than the one that holds your debt.",
    },
    {
      question: "Does this calculator include new purchases?",
      answer:
        "No. It assumes you make no further purchases on the card. New purchases may accrue interest at the regular rate and can complicate how your payments are applied, so avoid using the card until the balance is gone.",
    },
  ],
};
