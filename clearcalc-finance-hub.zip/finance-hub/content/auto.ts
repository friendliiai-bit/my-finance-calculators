import type { SeoCopy } from "@/components/SeoContent";

export const autoCopy: SeoCopy = {
  heading: "Financing a car versus paying cash",
  intro: [
    "Most people treat this as a question about interest, but it is really a question about what else your cash could do. If you pay cash, you avoid interest entirely and own the car outright. If you finance, you keep the money in your account and pay the lender for the privilege. This calculator compares the two by tracking what the loan costs you and what your cash earns while you hold it.",
    "Set the price, tax, down payment, loan terms and the return you expect on your cash. The chart shows interest paid against growth earned over the life of the loan, and the results state which path comes out ahead and by how much.",
  ],
  sections: [
    {
      heading: "The break-even rule",
      body: [
        "Financing beats paying cash only when your cash earns more than the loan costs, after tax. The calculator makes this exact: the break-even return equals the loan APR.",
        "With the default setup, a loan at 6.9% against a 5% expected return means paying cash comes out about $2,100 ahead on a $40,660 purchase. Lower the APR to 2% and the verdict flips, because the interest is small while your cash keeps working. Loan interest is a guaranteed cost and investment returns are not, so a near tie usually favors paying cash.",
      ],
    },
    {
      heading: "Why the return you assume matters so much",
      body: [
        "People often plug in a stock-market average and conclude that financing wins. That ignores risk and taxes. A stock portfolio can fall just when you need to make payments, while the loan payment never changes.",
        "A fair comparison uses something you could earn reliably, such as a high-yield savings rate or a short-term bond fund, after taxes. If you would invest in stocks, treat the result as a best case rather than a promise. The calculator also warns you if your invested cash would run out before the loan ends, which happens whenever your return is below the loan rate.",
      ],
    },
    {
      heading: "Down payment, term and sales tax",
      body: [
        "A larger down payment cuts the amount you borrow and the interest you pay, while a longer term lowers the monthly payment but raises total interest. Sales tax is usually added to the amount financed, so the calculator includes it in the cash price.",
        "Be careful with terms of 72 months or more. You may owe more than the car is worth for years, which is a problem if it is totaled or you want to sell. A shorter term has a higher payment but builds equity faster.",
      ],
    },
    {
      heading: "Promotions and rebates change the math",
      body: [
        "Manufacturers sometimes offer 0% financing or a cash rebate, but rarely both. A 0% loan makes financing very attractive because you borrow for free while your cash earns something. A rebate of a few thousand dollars may be worth more than the interest you would save, especially if you can get a low-rate loan from a credit union.",
        "Run both versions: the rebate-reduced price with a market APR in one pass, and the full price with the promotional APR in another. This calculator does not model rebates automatically.",
      ],
    },
    {
      heading: "Costs that do not change between the two paths",
      body: [
        "Depreciation, insurance, fuel and maintenance are the same whether you finance or pay cash, so they are left out. The real difference is the interest on one side and the growth on the other.",
        "Remember, too, the value of liquidity. Cash in the bank can cover a job loss or a surprise expense, while cash locked in a car cannot. If paying cash would leave you without an emergency fund, financing may be the safer choice even if it costs more.",
      ],
    },
    {
      heading: "How to compare dealer quotes fairly",
      body: [
        "Dealers can quote the same car several ways: a low monthly payment, a low APR or a low price. Compare them on total cost, not on any one figure. Ask for the out-the-door price, which includes taxes and fees, then ask what the monthly payment is for a specific term and APR. A lower payment achieved by stretching the term usually costs more in total interest, even when the rate looks attractive.",
        "Get a pre-approved rate from a bank or credit union before you visit, then use it as the APR on this page. If the dealer beats it, good. If not, you have a fallback and a negotiating position. Decline add-ons you have not priced separately, because financed extras are charged interest like everything else. Trade-in credits and rebates change the effective price too, so enter the price after those credits when you compare.",
        "When the numbers are final, enter the price and rate here to confirm what the loan really costs against paying cash.",
      ],
    },
    {
      heading: "A quick way to decide",
      body: [
        "Start with your emergency fund. If it is secure, compare the loan rate with the after-tax return you can count on. When the loan rate is higher, pay cash or put down more. When it is much lower, finance and keep the difference. In between, choose the option that lets you sleep, and shop for the lowest APR before you sign.",
      ],
    },
  ],
  faqs: [
    {
      question: "Is it better to pay cash for a car?",
      answer:
        "Often, when the loan rate is higher than what your cash would earn after tax. It also removes a payment and lowers your risk. If the loan rate is low, financing can leave you better off.",
    },
    {
      question: "Does paying cash help my credit score?",
      answer:
        "Paying cash neither builds nor harms your score. An auto loan can add positive history if you pay on time, but the effect is modest, so it is rarely a good reason to borrow.",
    },
    {
      question: "What if I can get 0% financing?",
      answer:
        "Take it seriously, as long as you do not give up a cash rebate worth more than the interest you would save. Set the APR slider to zero to see the effect.",
    },
    {
      question: "Should I put more money down?",
      answer:
        "A larger down payment reduces interest and helps you avoid owing more than the car is worth. Raise the slider and watch the interest fall, but keep enough cash for emergencies.",
    },
    {
      question: "Does this include depreciation?",
      answer:
        "No, because the car loses value the same way on both paths. Depreciation matters for how long you keep the car and how much you owe, but not for the finance-versus-cash decision.",
    },
  ],
};
