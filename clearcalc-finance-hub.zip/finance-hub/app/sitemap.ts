import type { MetadataRoute } from "next";
import { CALCULATOR_LIST } from "@/lib/calculators";
import { SITE } from "@/lib/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return [
    { url: SITE.url, lastModified: now, changeFrequency: "monthly", priority: 1 },
    ...CALCULATOR_LIST.map((c) => ({
      url: `${SITE.url}${c.href}`,
      lastModified: now,
      changeFrequency: "monthly" as const,
      priority: 0.8,
    })),
  ];
}
