import type { Metadata } from "next";
import Link from "next/link";
import { CalcGlyph } from "@/components/CalcGlyph";
import { HeroTeaser } from "@/components/HeroTeaser";
import { CALCULATOR_LIST } from "@/lib/calculators";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  alternates: { canonical: "/" },
};

export default function HomePage() {
  const siteLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: SITE.name,
    url: SITE.url,
    description: SITE.description,
  };

  return (
    <>
      <section className="page-head border-b border-line">
        <div className="mx-auto grid max-w-[1200px] items-center gap-10 px-4 pb-14 pt-12 sm:px-6 sm:pt-16 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)] lg:gap-16">
          <div>
            <h1 className="font-display text-[2.5rem] font-bold leading-[1.02] tracking-[-0.03em] sm:text-6xl">
              Run the numbers before you make the move.
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-ink-soft">
              Five calculators for money decisions that are hard to undo: retiring
              early, clearing debt, paying off a mortgage, taxing a side hustle
              and buying a car. Move a slider, watch the chart change, read the
              assumptions.
            </p>
          </div>
          <HeroTeaser />
        </div>
      </section>

      <section
        aria-labelledby="calculators-heading"
        className="mx-auto max-w-[1200px] px-4 py-14 sm:px-6"
      >
        <h2
          id="calculators-heading"
          className="font-display text-3xl font-bold tracking-tight"
        >
          Pick the decision in front of you
        </h2>
        <ul className="mt-6 divide-y divide-line border-y border-line">
          {CALCULATOR_LIST.map((c) => (
            <li key={c.key}>
              <Link
                href={c.href}
                className="group grid grid-cols-[auto_minmax(0,1fr)] items-center gap-x-5 gap-y-1 px-1 py-5 transition-colors hover:bg-panel sm:px-4"
              >
                <span className="row-span-2 text-brand-deep sm:row-span-1">
                  <CalcGlyph calc={c.key} />
                </span>
                <span className="grid gap-1 sm:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)] sm:items-baseline sm:gap-8">
                  <span className="font-display text-xl font-semibold tracking-tight group-hover:underline">
                    {c.title}
                  </span>
                  <span className="text-ink-soft">{c.question}</span>
                </span>
                <span className="text-sm leading-relaxed text-muted sm:col-start-2">
                  {c.tagline}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section
        aria-labelledby="trust-heading"
        className="mx-auto max-w-[1200px] px-4 pb-16 sm:px-6"
      >
        <h2
          id="trust-heading"
          className="font-display text-3xl font-bold tracking-tight"
        >
          How these calculators work
        </h2>
        <div className="mt-6 grid gap-8 md:grid-cols-3">
          <div>
            <h3 className="text-lg font-semibold">The math is plain</h3>
            <p className="mt-2 leading-relaxed text-ink-soft">
              Standard amortization, monthly compounding and the published 2026 US
              tax brackets. Each page lists its assumptions and shows its data as a
              table, so you can check any figure.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Your inputs stay with you</h3>
            <p className="mt-2 leading-relaxed text-ink-soft">
              Everything runs in your browser. The numbers you type are not sent
              to a server, saved or shared.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Estimates, not advice</h3>
            <p className="mt-2 leading-relaxed text-ink-soft">
              Real decisions involve details a slider cannot capture. Use these
              results to ask better questions of a planner, lender or tax
              professional.
            </p>
          </div>
        </div>
      </section>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(siteLd) }}
      />
    </>
  );
}
