import type { Metadata } from "next";
import { CalculatorPage } from "@/components/CalculatorPage";
import { AutoLoan } from "@/components/calculators/AutoLoan";
import { autoCopy } from "@/content/auto";
import { AFFILIATES } from "@/lib/affiliates";
import { CALCULATORS } from "@/lib/calculators";

const calc = CALCULATORS.auto;

export const metadata: Metadata = {
  title: calc.metaTitle,
  description: calc.metaDescription,
  alternates: { canonical: calc.href },
  openGraph: { title: calc.metaTitle, description: calc.metaDescription, url: calc.href },
};

export default function Page() {
  return (
    <CalculatorPage calc={calc} copy={autoCopy} affiliates={AFFILIATES.auto}>
      <AutoLoan />
    </CalculatorPage>
  );
}
