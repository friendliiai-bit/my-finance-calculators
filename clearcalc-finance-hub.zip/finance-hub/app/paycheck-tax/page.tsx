import type { Metadata } from "next";
import { CalculatorPage } from "@/components/CalculatorPage";
import { PaycheckTax } from "@/components/calculators/PaycheckTax";
import { taxCopy } from "@/content/tax";
import { AFFILIATES } from "@/lib/affiliates";
import { CALCULATORS } from "@/lib/calculators";

const calc = CALCULATORS.tax;

export const metadata: Metadata = {
  title: calc.metaTitle,
  description: calc.metaDescription,
  alternates: { canonical: calc.href },
  openGraph: { title: calc.metaTitle, description: calc.metaDescription, url: calc.href },
};

export default function Page() {
  return (
    <CalculatorPage calc={calc} copy={taxCopy} affiliates={AFFILIATES.tax}>
      <PaycheckTax />
    </CalculatorPage>
  );
}
