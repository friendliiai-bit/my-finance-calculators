import type { Metadata } from "next";
import { CalculatorPage } from "@/components/CalculatorPage";
import { FireCalculator } from "@/components/calculators/FireCalculator";
import { fireCopy } from "@/content/fire";
import { AFFILIATES } from "@/lib/affiliates";
import { CALCULATORS } from "@/lib/calculators";

const calc = CALCULATORS.fire;

export const metadata: Metadata = {
  title: calc.metaTitle,
  description: calc.metaDescription,
  alternates: { canonical: calc.href },
  openGraph: { title: calc.metaTitle, description: calc.metaDescription, url: calc.href },
};

export default function Page() {
  return (
    <CalculatorPage calc={calc} copy={fireCopy} affiliates={AFFILIATES.fire}>
      <FireCalculator />
    </CalculatorPage>
  );
}
