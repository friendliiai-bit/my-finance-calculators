import type { Metadata } from "next";
import { CalculatorPage } from "@/components/CalculatorPage";
import { MortgagePayoff } from "@/components/calculators/MortgagePayoff";
import { mortgageCopy } from "@/content/mortgage";
import { AFFILIATES } from "@/lib/affiliates";
import { CALCULATORS } from "@/lib/calculators";

const calc = CALCULATORS.mortgage;

export const metadata: Metadata = {
  title: calc.metaTitle,
  description: calc.metaDescription,
  alternates: { canonical: calc.href },
  openGraph: { title: calc.metaTitle, description: calc.metaDescription, url: calc.href },
};

export default function Page() {
  return (
    <CalculatorPage calc={calc} copy={mortgageCopy} affiliates={AFFILIATES.mortgage}>
      <MortgagePayoff />
    </CalculatorPage>
  );
}
