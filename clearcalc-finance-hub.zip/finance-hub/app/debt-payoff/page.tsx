import type { Metadata } from "next";
import { CalculatorPage } from "@/components/CalculatorPage";
import { DebtPayoff } from "@/components/calculators/DebtPayoff";
import { debtCopy } from "@/content/debt";
import { AFFILIATES } from "@/lib/affiliates";
import { CALCULATORS } from "@/lib/calculators";

const calc = CALCULATORS.debt;

export const metadata: Metadata = {
  title: calc.metaTitle,
  description: calc.metaDescription,
  alternates: { canonical: calc.href },
  openGraph: { title: calc.metaTitle, description: calc.metaDescription, url: calc.href },
};

export default function Page() {
  return (
    <CalculatorPage calc={calc} copy={debtCopy} affiliates={AFFILIATES.debt}>
      <DebtPayoff />
    </CalculatorPage>
  );
}
